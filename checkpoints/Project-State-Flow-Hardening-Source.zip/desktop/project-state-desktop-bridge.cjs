const fs = require("node:fs");
const fsp = require("node:fs/promises");
const path = require("node:path");
const os = require("node:os");
const crypto = require("node:crypto");
const zlib = require("node:zlib");
const { DatabaseSync } = require("node:sqlite");

const ROOT = path.join(__dirname, "..");
const SCHEMA_FILE = path.join(__dirname, "spine-schema.sql");
const API_ARM_CONTRACT_FILE = path.join(ROOT, "fixtures", "api-arm-v0.1-contract.json");
const DEFAULT_STORAGE_ROOT = path.join(os.homedir(), "Project State Storage");
const DATABASE_FILE = "project-state.db";
const FOLDERS = ["sources", "extracts", "attachments", "quarantine", "discovery", "backups", "recovery", "manifests", "logs", "temp", "integrations"];
const SPLIT_TABLES = ["projects", "changes", "sources", "extracts", "attachments", "draft_projects"];
const BACKUP_MANAGED_FOLDERS = ["sources", "extracts", "attachments", "quarantine", "discovery", "manifests", "recovery"];
const IMPORT_FILE_EXTENSIONS = new Set([".pdf", ".docx", ".txt", ".md", ".csv", ".json", ".png", ".jpg", ".jpeg", ".webp", ".gif"]);
const MAX_IMPORT_FILE_BYTES = 26214400;
const MAX_IMPORT_FILES = 500;
const REQUIRED_TABLES = [
  "meta",
  "actors",
  "projects",
  "decisions",
  "facts",
  "open_questions",
  "next_actions",
  "relationships",
  "changes",
  "sources",
  "extracts",
  "extract_chunks",
  "attachments",
  "source_links",
  "intake_batches",
  "intake_items",
  "proposed_projects",
  "proposal_items",
  "draft_projects",
  "approval_records",
  "recovery_records",
  "file_assets",
  "file_versions",
  "discovery_cases",
  "discovery_case_files",
  "discovery_interactions",
  "security_receipts",
  "discovery_events",
  "discovery_extractions",
  "discovery_chunks"
];

function createProjectStateDesktopBridge(options = {}) {
  const storageRoot = path.resolve(options.storageRoot || process.env.PROJECT_STATE_STORAGE_ROOT || DEFAULT_STORAGE_ROOT);
  const dbPath = path.join(storageRoot, DATABASE_FILE);

  return {
    label: options.label || "Project State Desktop Bridge",
    storageRoot,
    storage: {
      async loadStore(context = {}) {
        return loadStore({ storageRoot, dbPath, context });
      },
      async saveStore(payload = {}) {
        return saveStore({ storageRoot, dbPath, payload });
      },
      async saveMeta(payload = {}) {
        return saveMeta({ storageRoot, dbPath, payload });
      },
      async preserveLegacyRaw(raw = "") {
        return preserveLegacyRaw({ storageRoot, dbPath, raw });
      },
      async preserveRecoveryRecord(issue = {}) {
        return preserveRecoveryRecord({ storageRoot, dbPath, issue });
      },
      async verifyIntegrity(options = {}) {
        return verifyIntegrity({ storageRoot, dbPath, ...options });
      },
      async importBrowserExport(payload = {}) {
        return importBrowserExport({ storageRoot, dbPath, payload });
      },
      async createBackupPackage(payload = {}) {
        return createBackupPackage({ storageRoot, dbPath, payload });
      },
      async restoreBackupPackage(payload = {}) {
        return restoreBackupPackage({ storageRoot, dbPath, payload });
      },
      async reset() {
        return resetSpine({ storageRoot, dbPath });
      }
    },
    intakeArms: {
      async describeCapabilities() {
        return describeApiArmCapabilities();
      },
      async submitEnvelope(envelope = {}) {
        return submitApiArmEnvelope({ storageRoot, dbPath, envelope });
      },
      async getReceipt(submissionId = "") {
        return getApiArmReceipt({ storageRoot, dbPath, submissionId });
      }
    },
    discoveryStorage: {
      async initialize() {
        return initializeDiscoveryStorage({ storageRoot, dbPath });
      },
      async registerFileVersion(payload = {}) {
        return registerDiscoveryFileVersion({ storageRoot, dbPath, payload });
      },
      async createCase(payload = {}) {
        return createDiscoveryCase({ storageRoot, dbPath, payload });
      },
      async attachFileVersion(payload = {}) {
        return attachDiscoveryFileVersion({ storageRoot, dbPath, payload });
      },
      async appendInteraction(payload = {}) {
        return appendDiscoveryInteraction({ storageRoot, dbPath, payload });
      },
      async appendSecurityReceipt(payload = {}) {
        return appendDiscoverySecurityReceipt({ storageRoot, dbPath, payload });
      },
      async appendEvent(payload = {}) {
        return appendDiscoveryEvent({ storageRoot, dbPath, payload });
      },
      async readFoundationState(payload = {}) {
        return readDiscoveryFoundationState({ storageRoot, dbPath, payload });
      },
      async stageTrustedFile(payload = {}) {
        return stageTrustedDiscoveryFile({ storageRoot, dbPath, payload });
      },
      async extractFileVersion(payload = {}) {
        return extractDiscoveryFileVersion({ storageRoot, dbPath, payload });
      },
      async readExtractionText(payload = {}) {
        return readDiscoveryExtractionText({ storageRoot, dbPath, payload });
      },
      async analyzeCase(payload = {}) {
        return analyzeDiscoveryCase({ storageRoot, dbPath, payload });
      },
      async recordAnswer(payload = {}) {
        return recordDiscoveryAnswer({ storageRoot, dbPath, payload });
      },
      async confirmRouting(payload = {}) {
        return confirmDiscoveryRouting({ storageRoot, dbPath, payload });
      },
      async getCase(payload = {}) {
        return getDiscoveryCase({ storageRoot, dbPath, payload });
      },
      async promoteToIntake(payload = {}) {
        return promoteDiscoveryToIntake({ storageRoot, dbPath, payload });
      }
    },
    securityArms: {
      async authorizeContentAccess(reference = {}) {
        return authorizeDiscoveryContentAccess({ storageRoot, dbPath, reference });
      }
    },
    files: {
      metadata,
      localPath,
      async inspectImportSelection(payload = {}) {
        return inspectImportSelection(payload);
      },
      async stageManagedFiles(payload = {}) {
        return stageManagedFiles({ storageRoot, ...payload });
      },
      verifyLocalFile(reference = {}) {
        if (reference?.managedPath) {
          return verifyLocalFile({
            ...reference,
            path: resolveManagedPath(storageRoot, reference.managedPath)
          });
        }
        return verifyLocalFile(reference);
      },
      async readAsDataUrl(file) {
        await authorizeDiscoveryContentAccess({ storageRoot, dbPath, reference: file });
        return readAsDataUrl(resolveDiscoveryReadReference(storageRoot, file));
      },
      async readAsText(file) {
        await authorizeDiscoveryContentAccess({ storageRoot, dbPath, reference: file });
        return readAsText(resolveDiscoveryReadReference(storageRoot, file));
      },
      async readAsArrayBuffer(file) {
        await authorizeDiscoveryContentAccess({ storageRoot, dbPath, reference: file });
        return readAsArrayBuffer(resolveDiscoveryReadReference(storageRoot, file));
      },
      async extractText(file) {
        await authorizeDiscoveryContentAccess({ storageRoot, dbPath, reference: file });
        return extractText(resolveDiscoveryReadReference(storageRoot, file));
      },
      async inflateRaw(bytes) {
        return new Uint8Array(zlib.inflateRawSync(Buffer.from(bytes)));
      }
    },
    downloads: {
      async saveTextFile({ fileName, text, type = "text/plain" } = {}) {
        return saveTextFile({ storageRoot, fileName, text, type });
      }
    }
  };
}

async function inspectImportSelection({ paths = [] } = {}) {
  const candidates = [];
  const skipped = [];
  const seen = new Set();

  async function inspectPath(inputPath) {
    if (candidates.length >= MAX_IMPORT_FILES) {
      skipped.push({ localPath: String(inputPath || ""), reason: "File selection limit reached." });
      return;
    }
    const localPath = path.resolve(String(inputPath || ""));
    if (seen.has(localPath)) return;
    seen.add(localPath);
    let stat;
    try {
      stat = await fsp.lstat(localPath);
    } catch {
      skipped.push({ localPath, reason: "File or folder could not be read." });
      return;
    }
    if (stat.isSymbolicLink()) {
      skipped.push({ localPath, reason: "Symbolic links are not imported." });
      return;
    }
    if (stat.isDirectory()) {
      const entries = await fsp.readdir(localPath);
      for (const entry of entries.sort((a, b) => a.localeCompare(b))) await inspectPath(path.join(localPath, entry));
      return;
    }
    if (!stat.isFile()) return;
    const extension = path.extname(localPath).toLowerCase();
    if (!IMPORT_FILE_EXTENSIONS.has(extension)) {
      skipped.push({ localPath, reason: "File type is not supported." });
      return;
    }
    if (!stat.size) {
      skipped.push({ localPath, reason: "Empty files are not imported." });
      return;
    }
    if (stat.size > MAX_IMPORT_FILE_BYTES) {
      skipped.push({ localPath, reason: "File exceeds the 25 MB import limit." });
      return;
    }
    candidates.push({
      localPath,
      name: path.basename(localPath),
      contentType: mimeFromFileName(localPath),
      size: stat.size,
      lastModified: stat.mtime.toISOString()
    });
  }

  for (const inputPath of Array.isArray(paths) ? paths : []) await inspectPath(inputPath);
  return { candidates, skipped, limits: { maxFiles: MAX_IMPORT_FILES, maxFileBytes: MAX_IMPORT_FILE_BYTES } };
}

async function stageManagedFiles({ storageRoot, files = [] } = {}) {
  await ensureSpine(storageRoot);
  const staged = [];
  const errors = [];
  for (const file of Array.isArray(files) ? files.slice(0, MAX_IMPORT_FILES) : []) {
    const intakeId = String(file.intakeId || "").trim();
    const localPath = path.resolve(String(file.localPath || ""));
    try {
      if (!/^intake_[A-Za-z0-9_-]+$/.test(intakeId)) throw new Error("A valid Intake ID is required.");
      const stat = await fsp.lstat(localPath);
      const extension = path.extname(localPath).toLowerCase();
      if (!stat.isFile() || stat.isSymbolicLink()) throw new Error("Only regular files can be imported.");
      if (!IMPORT_FILE_EXTENSIONS.has(extension)) throw new Error("File type is not supported.");
      if (!stat.size || stat.size > MAX_IMPORT_FILE_BYTES) throw new Error("File size is outside the allowed range.");
      const bytes = await fsp.readFile(localPath);
      const sha256 = crypto.createHash("sha256").update(bytes).digest("hex");
      const fileName = safeFileName(path.basename(localPath));
      const targetPath = path.join(storageRoot, "sources", intakeId, fileName);
      const tempPath = path.join(storageRoot, "temp", `${intakeId}-${Date.now()}-${fileName}.import`);
      await fsp.mkdir(path.dirname(tempPath), { recursive: true });
      await fsp.writeFile(tempPath, bytes, { flag: "wx" });
      await fsp.mkdir(path.dirname(targetPath), { recursive: true });
      await fsp.rename(tempPath, targetPath);
      staged.push({
        intakeId,
        fileName,
        contentType: mimeFromFileName(fileName),
        size: bytes.length,
        sha256,
        managedPath: relativeManagedPath(storageRoot, targetPath),
        originalPath: localPath,
        lastModified: stat.mtime.toISOString()
      });
    } catch (error) {
      errors.push({ intakeId, localPath, message: error.message });
    }
  }
  return { staged, errors };
}

function readApiArmContract() {
  return JSON.parse(fs.readFileSync(API_ARM_CONTRACT_FILE, "utf8"));
}

function describeApiArmCapabilities() {
  const contract = readApiArmContract();
  return {
    app: contract.app,
    contractType: contract.contractType,
    contractVersion: contract.contractVersion,
    runtime: contract.runtime,
    implementationStatus: contract.implementationStatus,
    operations: [...contract.operations],
    allowedArmTypes: [...contract.allowedArmTypes],
    allowedProposalTypes: [...contract.allowedProposalTypes],
    receiptBoundary: contract.receiptBoundary,
    unsupportedPayloads: [...contract.unsupportedPayloads]
  };
}

async function submitApiArmEnvelope({ storageRoot, dbPath, envelope }) {
  await ensureSpine(storageRoot);
  const db = openDatabase(dbPath);
  const contract = readApiArmContract();
  const submissionId = cleanText(envelope?.submissionId);
  const idempotencyKey = cleanText(envelope?.idempotencyKey);
  let transactionOpen = false;

  try {
    const errors = validateApiArmEnvelope(envelope, contract, db);
    if (errors.length) return rejectedApiArmReceipt(contract, submissionId, idempotencyKey, errors);

    const canonicalPayload = stableStringify(envelope);
    const payloadChecksum = checksumText(canonicalPayload);
    const priorBatch = findApiArmBatch(db, submissionId, idempotencyKey);
    if (priorBatch) {
      if (priorBatch.payloadChecksum !== payloadChecksum) {
        return rejectedApiArmReceipt(contract, submissionId, idempotencyKey, [{
          code: "IDEMPOTENCY_CONFLICT",
          message: "The submission ID or idempotency key was already used with different content.",
          path: "idempotencyKey"
        }]);
      }
      return { ...priorBatch.receipt, status: "duplicate" };
    }

    const receivedAt = nowIso();
    const batchId = makeId("intake_batch");
    const itemMappings = envelope.items.map((item) => ({
      clientItemId: cleanText(item.clientItemId),
      intakeId: makeId("intake")
    }));
    const receipt = {
      contractVersion: contract.contractVersion,
      submissionId,
      idempotencyKey,
      batchId,
      itemMappings,
      status: "accepted",
      receivedAt,
      boundary: contract.receiptBoundary
    };
    const batch = {
      id: batchId,
      status: "pending",
      createdAt: receivedAt,
      submissionId,
      idempotencyKey,
      payloadChecksum,
      projectId: cleanText(envelope.target.projectId),
      arm: cloneJson(envelope.arm),
      provenance: cloneJson(envelope.provenance),
      itemIds: itemMappings.map((mapping) => mapping.intakeId),
      receipt
    };
    const mappingByClientId = new Map(itemMappings.map((mapping) => [mapping.clientItemId, mapping.intakeId]));
    const intakeItems = envelope.items.map((item) => ({
      id: mappingByClientId.get(cleanText(item.clientItemId)),
      intakeBatchId: batchId,
      apiArmSubmissionId: submissionId,
      apiArmClientItemId: cleanText(item.clientItemId),
      apiArmIdempotencyKey: idempotencyKey,
      apiArm: cloneJson(envelope.arm),
      provenance: cloneJson(envelope.provenance),
      armType: envelope.arm.type,
      status: "pending",
      reviewState: "needs_review",
      queueState: "new",
      queueNotes: "",
      queueReviewedAt: "",
      queueReviewedBy: "",
      queueReviewReason: "",
      title: cleanText(item.title),
      projectId: cleanText(envelope.target.projectId),
      createdAt: receivedAt,
      createdBy: "",
      sourceLabel: cleanText(item.sourceLabel) || cleanText(envelope.provenance.sourceLabel),
      proposedObjectType: item.proposedObjectType,
      proposedChange: cloneJson(item.proposedChange),
      evidence: cloneJson(item.evidence || {}),
      approval: null,
      assignments: [],
      comments: [],
      archived: false
    }));

    db.exec("BEGIN IMMEDIATE TRANSACTION");
    transactionOpen = true;
    writeIntakeBatches(db, [batch]);
    writeIntakeItems(db, intakeItems);
    updateApiArmStoreMeta(db, batch, intakeItems);
    db.exec("COMMIT");
    transactionOpen = false;
    return receipt;
  } catch (error) {
    if (transactionOpen) {
      try {
        db.exec("ROLLBACK");
      } catch {}
    }
    await preserveRecoveryRecordWithOpenDb(db, storageRoot, {
      stage: "api-arm-submit",
      message: error.message,
      stack: error.stack || "",
      raw: safeJson(envelope)
    });
    return rejectedApiArmReceipt(contract, submissionId, idempotencyKey, [{
      code: "PERSISTENCE_FAILED",
      message: "Project State could not retain the API arm proposal.",
      path: ""
    }]);
  } finally {
    db.close();
  }
}

async function getApiArmReceipt({ storageRoot, dbPath, submissionId }) {
  await ensureSpine(storageRoot);
  if (!cleanText(submissionId) || !fs.existsSync(dbPath)) return null;
  const db = openDatabase(dbPath);
  try {
    const batch = readRecordJson(db, "intake_batches").find((record) => record.submissionId === cleanText(submissionId));
    return batch?.receipt ? cloneJson(batch.receipt) : null;
  } finally {
    db.close();
  }
}

function validateApiArmEnvelope(envelope, contract, db) {
  const errors = [];
  const add = (code, message, path = "") => errors.push({ code, message, path });
  if (!envelope || typeof envelope !== "object" || Array.isArray(envelope)) {
    add("INVALID_ENVELOPE", "Submission envelope must be an object.");
    return errors;
  }
  if (envelope.contractVersion !== contract.contractVersion) add("UNSUPPORTED_CONTRACT_VERSION", `Contract version must be ${contract.contractVersion}.`, "contractVersion");
  for (const field of contract.envelope.required) if (isBlank(envelope[field])) add("INVALID_ENVELOPE", `${field} is required.`, field);
  if (!validIsoTimestamp(envelope.submittedAt)) add("INVALID_ENVELOPE", "submittedAt must be an ISO 8601 timestamp.", "submittedAt");

  const allowedTopLevel = new Set([...contract.envelope.required]);
  for (const key of Object.keys(envelope)) if (!allowedTopLevel.has(key)) add("INVALID_ENVELOPE", `Unsupported envelope field: ${key}.`, key);

  const forbidden = findForbiddenFields(envelope, new Set(contract.forbiddenSubmissionFields));
  for (const fieldPath of forbidden) add("FORBIDDEN_FIELD", "The arm cannot provide this server-owned or unsupported field.", fieldPath);

  const arm = envelope.arm;
  if (!arm || typeof arm !== "object" || Array.isArray(arm)) {
    add("INVALID_ARM", "arm must be an object.", "arm");
  } else {
    for (const field of contract.envelope.armRequired) if (isBlank(arm[field])) add("INVALID_ARM", `${field} is required.`, `arm.${field}`);
    if (!contract.allowedArmTypes.includes(arm.type)) add("INVALID_ARM", "Unsupported arm type.", "arm.type");
    const allowed = new Set([...contract.envelope.armRequired, "instanceId"]);
    for (const key of Object.keys(arm)) if (!allowed.has(key)) add("INVALID_ARM", `Unsupported arm field: ${key}.`, `arm.${key}`);
  }

  const target = envelope.target;
  if (!target || typeof target !== "object" || Array.isArray(target)) {
    add("INVALID_TARGET_PROJECT", "target must be an object.", "target");
  } else {
    for (const field of contract.envelope.targetRequired) if (isBlank(target[field])) add("INVALID_TARGET_PROJECT", `${field} is required.`, `target.${field}`);
    const projectId = cleanText(target.projectId);
    if (projectId && !db.prepare("SELECT id FROM projects WHERE id = ?").get(projectId)) add("INVALID_TARGET_PROJECT", "Target Project ID does not exist.", "target.projectId");
    for (const key of Object.keys(target)) if (!contract.envelope.targetRequired.includes(key)) add("INVALID_TARGET_PROJECT", `Unsupported target field: ${key}.`, `target.${key}`);
  }

  const provenance = envelope.provenance;
  if (!provenance || typeof provenance !== "object" || Array.isArray(provenance)) {
    add("INVALID_ENVELOPE", "provenance must be an object.", "provenance");
  } else {
    for (const field of contract.envelope.provenanceRequired) if (isBlank(provenance[field])) add("INVALID_ENVELOPE", `${field} is required.`, `provenance.${field}`);
    const allowed = new Set([...contract.envelope.provenanceRequired, "externalReference", "capturedAt"]);
    for (const key of Object.keys(provenance)) if (!allowed.has(key)) add("INVALID_ENVELOPE", `Unsupported provenance field: ${key}.`, `provenance.${key}`);
    if (provenance.capturedAt && !validIsoTimestamp(provenance.capturedAt)) add("INVALID_ENVELOPE", "capturedAt must be an ISO 8601 timestamp.", "provenance.capturedAt");
  }

  if (!Array.isArray(envelope.items) || !envelope.items.length) {
    add("INVALID_ENVELOPE", "items must contain at least one proposal.", "items");
  } else {
    const clientIds = new Set();
    envelope.items.forEach((item, index) => {
      const base = `items[${index}]`;
      if (!item || typeof item !== "object" || Array.isArray(item)) {
        add("INVALID_ENVELOPE", "Proposal item must be an object.", base);
        return;
      }
      for (const field of contract.envelope.itemRequired) if (isBlank(item[field])) add("INVALID_ENVELOPE", `${field} is required.`, `${base}.${field}`);
      const clientItemId = cleanText(item.clientItemId);
      if (clientItemId && clientIds.has(clientItemId)) add("DUPLICATE_CLIENT_ITEM_ID", "clientItemId must be unique within the envelope.", `${base}.clientItemId`);
      clientIds.add(clientItemId);
      if (!contract.allowedProposalTypes.includes(item.proposedObjectType)) add("INVALID_PROPOSAL_TYPE", "Unsupported proposal type.", `${base}.proposedObjectType`);
      const allowedItem = new Set([...contract.envelope.itemRequired, "sourceLabel", "evidence"]);
      for (const key of Object.keys(item)) if (!allowedItem.has(key)) add("INVALID_ENVELOPE", `Unsupported proposal item field: ${key}.`, `${base}.${key}`);
      if (!item.proposedChange || typeof item.proposedChange !== "object" || Array.isArray(item.proposedChange)) {
        add("INVALID_ENVELOPE", "proposedChange must be an object.", `${base}.proposedChange`);
      } else {
        for (const field of contract.envelope.proposedChangeRequired) if (isBlank(item.proposedChange[field])) add("INVALID_ENVELOPE", `${field} is required.`, `${base}.proposedChange.${field}`);
        for (const key of Object.keys(item.proposedChange)) if (!contract.envelope.allowedProposedChangeFields.includes(key)) add("INVALID_ENVELOPE", `Unsupported proposedChange field: ${key}.`, `${base}.proposedChange.${key}`);
      }
    });
  }
  return dedupeErrors(errors);
}

function findApiArmBatch(db, submissionId, idempotencyKey) {
  return readRecordJson(db, "intake_batches").find((batch) => batch.submissionId === submissionId || batch.idempotencyKey === idempotencyKey) || null;
}

function updateApiArmStoreMeta(db, batch, intakeItems) {
  const storeMeta = readMeta(db, "store") || {};
  const currentBatches = readRecordJson(db, "intake_batches");
  const currentItems = readRecordJson(db, "intake_items");
  writeMeta(db, "store", { ...storeMeta, intakeBatches: currentBatches, intakeItems: currentItems });

  const snapshot = readMeta(db, "snapshot");
  if (snapshot?.store) {
    const nextStore = { ...snapshot.store, intakeBatches: currentBatches, intakeItems: currentItems };
    writeMeta(db, "snapshot", { store: nextStore, snapshotBytes: Buffer.byteLength(JSON.stringify(nextStore), "utf8") });
  }
  const manifest = readMeta(db, "manifest");
  if (manifest) writeMeta(db, "manifest", { ...manifest, counts: { ...(manifest.counts || {}), intakeBatches: currentBatches.length, intakeItems: currentItems.length } });
}

function rejectedApiArmReceipt(contract, submissionId, idempotencyKey, errors) {
  return {
    contractVersion: contract.contractVersion,
    submissionId,
    idempotencyKey,
    status: "rejected",
    boundary: contract.receiptBoundary,
    errors
  };
}

function findForbiddenFields(value, forbidden, pathParts = [], found = []) {
  if (!value || typeof value !== "object") return found;
  if (Array.isArray(value)) {
    value.forEach((entry, index) => findForbiddenFields(entry, forbidden, [...pathParts, `[${index}]`], found));
    return found;
  }
  for (const [key, entry] of Object.entries(value)) {
    const nextPath = pathParts.length && pathParts[pathParts.length - 1].startsWith("[")
      ? `${pathParts.slice(0, -1).join(".")}${pathParts[pathParts.length - 1]}.${key}`
      : [...pathParts, key].join(".");
    if (forbidden.has(key)) found.push(nextPath);
    findForbiddenFields(entry, forbidden, [...pathParts, key], found);
  }
  return found;
}

function dedupeErrors(errors) {
  const seen = new Set();
  return errors.filter((error) => {
    const key = `${error.code}|${error.path}|${error.message}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function isBlank(value) {
  if (value === null || value === undefined) return true;
  if (typeof value === "string") return !value.trim();
  return false;
}

function validIsoTimestamp(value) {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}T/.test(value) && !Number.isNaN(Date.parse(value));
}

function stableStringify(value) {
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  if (value && typeof value === "object") return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(",")}}`;
  return JSON.stringify(value);
}

function cloneJson(value) {
  return JSON.parse(JSON.stringify(value ?? {}));
}

function safeJson(value) {
  try {
    return JSON.stringify(value);
  } catch {
    return "[unserializable API arm envelope]";
  }
}

function cleanText(value) {
  return String(value || "").trim();
}

async function ensureSpine(storageRoot) {
  await fsp.mkdir(storageRoot, { recursive: true });
  await Promise.all(FOLDERS.map((folder) => fsp.mkdir(path.join(storageRoot, folder), { recursive: true })));
}

function openDatabase(dbPath) {
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec("PRAGMA busy_timeout = 5000;");
  db.exec(fs.readFileSync(SCHEMA_FILE, "utf8"));
  return db;
}

const DISCOVERY_CASE_STATUSES = new Set(["created", "security_pending", "security_blocked", "extracting", "questioning", "routing", "ready_for_intake", "promoted", "archived"]);
const DISCOVERY_STAGES = new Set(["add", "quarantine", "security", "extract", "discovery", "questions", "routing", "intake", "human_approval", "core"]);
const DISCOVERY_PRIVACY_CLASSES = new Set(["local_only", "personal", "confidential", "restricted", "provider_allowed"]);
const DISCOVERY_INTERACTION_TYPES = new Set(["system_question", "user_answer", "user_correction", "machine_suggestion", "routing_proposal", "routing_confirmation", "processing_event"]);
const SECURITY_VERDICTS = new Set(["clean", "threat_detected", "suspicious", "unknown", "error"]);

async function initializeDiscoveryStorage({ storageRoot, dbPath }) {
  await ensureSpine(storageRoot);
  const db = openDatabase(dbPath);
  try {
    return {
      ok: true,
      source: "discovery-storage-foundation",
      schema: readMeta(db, "discovery_schema"),
      counts: discoveryTableCounts(db)
    };
  } finally {
    db.close();
  }
}

async function registerDiscoveryFileVersion({ storageRoot, dbPath, payload = {} }) {
  await ensureSpine(storageRoot);
  const requestedAssetId = requiredDiscoveryId(payload.fileAssetId || payload.assetId, "File Asset ID");
  const requestedVersionId = requiredDiscoveryId(payload.fileVersionId || payload.versionId, "File Version ID");
  const sha256 = requiredSha256(payload.sha256);
  const byteSize = Number(payload.byteSize);
  if (!Number.isSafeInteger(byteSize) || byteSize < 0) throw new Error("File Version byte size must be a non-negative integer.");
  const originalName = requiredDiscoveryText(payload.originalName, "File Version original name");
  const managedPath = requiredQuarantinePath(payload.managedPath);
  const createdAt = requiredDiscoveryTimestamp(payload.createdAt || nowIso(), "File Version createdAt");
  const privacyClass = String(payload.privacyClass || "local_only");
  if (!DISCOVERY_PRIVACY_CLASSES.has(privacyClass)) throw new Error("File Asset privacy class is not supported.");

  const physicalPath = resolveManagedPath(storageRoot, managedPath);
  if (!fs.existsSync(physicalPath) || !fs.statSync(physicalPath).isFile()) throw new Error("Quarantined File Version is missing.");
  const physicalSize = fs.statSync(physicalPath).size;
  if (physicalSize !== byteSize) throw new Error("Quarantined File Version byte size mismatch.");
  if (await checksumFile(physicalPath) !== sha256) throw new Error("Quarantined File Version checksum mismatch.");

  const db = openDatabase(dbPath);
  try {
    db.exec("BEGIN IMMEDIATE TRANSACTION");
    const assetMatch = db.prepare("SELECT id, record_json FROM file_assets WHERE sha256 = ?").get(sha256);
    const assetId = assetMatch?.id || requestedAssetId;
    if (!assetMatch) {
      const asset = {
        id: assetId,
        sha256,
        createdAt,
        privacyClass,
        retentionState: payload.retentionState || "active"
      };
      insertStrict(db, "file_assets", {
        id: asset.id,
        sha256,
        created_at: createdAt,
        privacy_class: privacyClass,
        retention_state: asset.retentionState,
        record_json: JSON.stringify(asset)
      });
    }

    const versionMatch = db.prepare("SELECT id, record_json FROM file_versions WHERE file_asset_id = ? AND sha256 = ?").get(assetId, sha256);
    if (versionMatch) {
      db.exec("COMMIT");
      return {
        ok: true,
        deduplicated: true,
        fileAsset: JSON.parse(assetMatch?.record_json || db.prepare("SELECT record_json FROM file_assets WHERE id = ?").get(assetId).record_json),
        fileVersion: JSON.parse(versionMatch.record_json)
      };
    }

    const version = {
      id: requestedVersionId,
      fileAssetId: assetId,
      sha256,
      byteSize,
      originalName,
      managedPath,
      createdAt,
      securityState: payload.externalSecurityAcknowledged ? "external_responsibility_acknowledged" : "unacknowledged",
      externalSecurityAcknowledged: payload.externalSecurityAcknowledged === true,
      externalSecurityAcknowledgedBy: payload.externalSecurityAcknowledgedBy || "",
      externalSecurityAcknowledgedAt: payload.externalSecurityAcknowledgedAt || "",
      externalSecurityReason: String(payload.externalSecurityReason || "")
    };
    insertStrict(db, "file_versions", {
      id: version.id,
      file_asset_id: assetId,
      sha256,
      byte_size: byteSize,
      original_name: originalName,
      managed_path: managedPath,
      created_at: createdAt,
      record_json: JSON.stringify(version)
    });
    db.exec("COMMIT");
    return {
      ok: true,
      deduplicated: Boolean(assetMatch),
      fileAsset: assetMatch ? JSON.parse(assetMatch.record_json) : dbRecord(db, "file_assets", assetId),
      fileVersion: version
    };
  } catch (error) {
    try { db.exec("ROLLBACK"); } catch {}
    throw error;
  } finally {
    db.close();
  }
}

async function createDiscoveryCase({ storageRoot, dbPath, payload = {} }) {
  await ensureSpine(storageRoot);
  const id = requiredDiscoveryId(payload.id || payload.discoveryCaseId, "Discovery Case ID");
  const createdBy = requiredDiscoveryId(payload.createdBy || payload.actorId, "Discovery Case creator");
  const createdAt = requiredDiscoveryTimestamp(payload.createdAt || nowIso(), "Discovery Case createdAt");
  const stage = String(payload.stage || "quarantine");
  const status = String(payload.status || "created");
  if (!DISCOVERY_STAGES.has(stage)) throw new Error("Discovery Case stage is not supported.");
  if (!DISCOVERY_CASE_STATUSES.has(status)) throw new Error("Discovery Case status is not supported.");
  const record = {
    ...cloneJson(payload),
    id,
    createdBy,
    createdAt,
    updatedAt: createdAt,
    stage,
    status,
    confirmedProjectId: payload.confirmedProjectId || null
  };
  const db = openDatabase(dbPath);
  try {
    insertStrict(db, "discovery_cases", {
      id,
      created_by: createdBy,
      created_at: createdAt,
      updated_at: createdAt,
      stage,
      status,
      confirmed_project_id: record.confirmedProjectId,
      record_json: JSON.stringify(record)
    });
    return { ok: true, discoveryCase: record };
  } finally {
    db.close();
  }
}

async function attachDiscoveryFileVersion({ storageRoot, dbPath, payload = {} }) {
  await ensureSpine(storageRoot);
  const id = requiredDiscoveryId(payload.id || payload.membershipId, "Discovery file membership ID");
  const discoveryCaseId = requiredDiscoveryId(payload.discoveryCaseId, "Discovery Case ID");
  const fileAssetId = requiredDiscoveryId(payload.fileAssetId, "File Asset ID");
  const fileVersionId = requiredDiscoveryId(payload.fileVersionId, "File Version ID");
  const addedAt = requiredDiscoveryTimestamp(payload.addedAt || nowIso(), "Discovery file addedAt");
  const record = { id, discoveryCaseId, fileAssetId, fileVersionId, addedAt, groupingRationale: String(payload.groupingRationale || "") };
  const db = openDatabase(dbPath);
  try {
    insertStrict(db, "discovery_case_files", {
      id,
      discovery_case_id: discoveryCaseId,
      file_asset_id: fileAssetId,
      file_version_id: fileVersionId,
      added_at: addedAt,
      grouping_rationale: record.groupingRationale,
      record_json: JSON.stringify(record)
    });
    return { ok: true, membership: record };
  } finally {
    db.close();
  }
}

async function appendDiscoveryInteraction({ storageRoot, dbPath, payload = {} }) {
  await ensureSpine(storageRoot);
  const id = requiredDiscoveryId(payload.id, "Interaction ID");
  const discoveryCaseId = requiredDiscoveryId(payload.discoveryCaseId, "Discovery Case ID");
  const actorId = requiredDiscoveryId(payload.actorId, "Interaction actor ID");
  const actorType = requiredDiscoveryText(payload.actorType, "Interaction actor type");
  const interactionType = String(payload.interactionType || "");
  if (!DISCOVERY_INTERACTION_TYPES.has(interactionType)) throw new Error("Discovery interaction type is not supported.");
  if (actorType !== "human" && ["user_answer", "user_correction", "routing_confirmation"].includes(interactionType)) {
    throw new Error("Only a human actor may append a user answer, correction, or routing confirmation.");
  }
  const createdAt = requiredDiscoveryTimestamp(payload.createdAt || nowIso(), "Interaction createdAt");
  const record = { ...cloneJson(payload), id, discoveryCaseId, actorId, actorType, interactionType, createdAt };
  const db = openDatabase(dbPath);
  try {
    insertStrict(db, "discovery_interactions", {
      id,
      discovery_case_id: discoveryCaseId,
      actor_id: actorId,
      actor_type: actorType,
      interaction_type: interactionType,
      created_at: createdAt,
      supersedes_interaction_id: payload.supersedesInteractionId || null,
      record_json: JSON.stringify(record)
    });
    return { ok: true, interaction: record };
  } finally {
    db.close();
  }
}

async function appendDiscoverySecurityReceipt({ storageRoot, dbPath, payload = {} }) {
  await ensureSpine(storageRoot);
  const id = requiredDiscoveryId(payload.id, "Security Receipt ID");
  const scanJobId = requiredDiscoveryId(payload.scanJobId, "Security scan job ID");
  const fileAssetId = requiredDiscoveryId(payload.fileAssetId, "File Asset ID");
  const fileVersionId = requiredDiscoveryId(payload.fileVersionId, "File Version ID");
  const sha256 = requiredSha256(payload.sha256);
  const verdict = String(payload.verdict || "");
  if (!SECURITY_VERDICTS.has(verdict)) throw new Error("Security Receipt verdict is not supported.");
  const eligible = verdict === "clean";
  const providerId = requiredDiscoveryText(payload.providerId, "Security provider ID");
  const startedAt = requiredDiscoveryTimestamp(payload.startedAt, "Security Receipt startedAt");
  const completedAt = requiredDiscoveryTimestamp(payload.completedAt, "Security Receipt completedAt");
  const record = { ...cloneJson(payload), id, scanJobId, fileAssetId, fileVersionId, sha256, verdict, eligible, providerId, startedAt, completedAt };
  const db = openDatabase(dbPath);
  try {
    insertStrict(db, "security_receipts", {
      id,
      scan_job_id: scanJobId,
      file_asset_id: fileAssetId,
      file_version_id: fileVersionId,
      sha256,
      verdict,
      eligible: eligible ? 1 : 0,
      provider_id: providerId,
      started_at: startedAt,
      completed_at: completedAt,
      supersedes_receipt_id: payload.supersedesReceiptId || null,
      record_json: JSON.stringify(record)
    });
    return { ok: true, securityReceipt: record };
  } finally {
    db.close();
  }
}

async function appendDiscoveryEvent({ storageRoot, dbPath, payload = {} }) {
  await ensureSpine(storageRoot);
  const id = requiredDiscoveryId(payload.id, "Discovery Event ID");
  const discoveryCaseId = requiredDiscoveryId(payload.discoveryCaseId, "Discovery Case ID");
  const eventType = requiredDiscoveryText(payload.eventType, "Discovery Event type");
  const actorId = requiredDiscoveryId(payload.actorId, "Discovery Event actor ID");
  const actorType = requiredDiscoveryText(payload.actorType, "Discovery Event actor type");
  const occurredAt = requiredDiscoveryTimestamp(payload.occurredAt || nowIso(), "Discovery Event occurredAt");
  const record = { ...cloneJson(payload), id, discoveryCaseId, eventType, actorId, actorType, occurredAt };
  const db = openDatabase(dbPath);
  try {
    insertStrict(db, "discovery_events", {
      id,
      discovery_case_id: discoveryCaseId,
      event_type: eventType,
      actor_id: actorId,
      actor_type: actorType,
      occurred_at: occurredAt,
      record_json: JSON.stringify(record)
    });
    return { ok: true, discoveryEvent: record };
  } finally {
    db.close();
  }
}

async function readDiscoveryFoundationState({ storageRoot, dbPath, payload = {} }) {
  await ensureSpine(storageRoot);
  const db = openDatabase(dbPath);
  try {
    const caseId = String(payload.discoveryCaseId || "").trim();
    const cases = caseId
      ? db.prepare("SELECT record_json FROM discovery_cases WHERE id = ?").all(caseId).map(parseRecordRow)
      : readRecordJson(db, "discovery_cases");
    const whereCase = (table) => caseId
      ? db.prepare(`SELECT record_json FROM ${table} WHERE discovery_case_id = ? ORDER BY rowid`).all(caseId).map(parseRecordRow)
      : readRecordJson(db, table);
    return {
      ok: true,
      schema: readMeta(db, "discovery_schema"),
      counts: discoveryTableCounts(db),
      fileAssets: readRecordJson(db, "file_assets"),
      fileVersions: readRecordJson(db, "file_versions"),
      discoveryCases: cases,
      caseFiles: whereCase("discovery_case_files"),
      interactions: whereCase("discovery_interactions"),
      securityReceipts: readRecordJson(db, "security_receipts"),
      events: whereCase("discovery_events"),
      extractions: whereCase("discovery_extractions"),
      chunks: readDiscoveryChunks(db, caseId)
    };
  } finally {
    db.close();
  }
}

function discoveryTableCounts(db) {
  return {
    fileAssets: countRows(db, "file_assets"),
    fileVersions: countRows(db, "file_versions"),
    discoveryCases: countRows(db, "discovery_cases"),
    caseFiles: countRows(db, "discovery_case_files"),
    interactions: countRows(db, "discovery_interactions"),
    securityReceipts: countRows(db, "security_receipts"),
    events: countRows(db, "discovery_events"),
    extractions: countRows(db, "discovery_extractions"),
    chunks: countRows(db, "discovery_chunks")
  };
}

function requiredDiscoveryId(value, label) {
  const text = String(value || "").trim();
  if (!text || !/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(text)) throw new Error(`${label} is required and must be a stable ID.`);
  return text;
}

function requiredDiscoveryText(value, label) {
  const text = String(value || "").trim();
  if (!text) throw new Error(`${label} is required.`);
  return text;
}

function requiredDiscoveryTimestamp(value, label) {
  if (!validIsoTimestamp(value)) throw new Error(`${label} must be a valid ISO timestamp.`);
  return String(value);
}

function requiredSha256(value) {
  const text = String(value || "").trim().toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(text)) throw new Error("File Version SHA-256 must contain 64 hexadecimal characters.");
  return text;
}

function requiredQuarantinePath(value) {
  const text = String(value || "").replace(/\\/g, "/").replace(/^\.\//, "");
  if (!text.startsWith("quarantine/") || text.includes("../") || path.isAbsolute(text)) throw new Error("File Version managed path must remain inside quarantine/.");
  return text;
}

function insertStrict(db, table, row) {
  const keys = Object.keys(row);
  const placeholders = keys.map(() => "?").join(", ");
  db.prepare(`INSERT INTO ${table} (${keys.join(", ")}) VALUES (${placeholders})`).run(...keys.map((key) => row[key]));
}

function dbRecord(db, table, id) {
  const row = db.prepare(`SELECT record_json FROM ${table} WHERE id = ?`).get(id);
  return row ? JSON.parse(row.record_json) : null;
}

function parseRecordRow(row) {
  return JSON.parse(row.record_json);
}

function readDiscoveryChunks(db, caseId = "") {
  if (!caseId) return readRecordJson(db, "discovery_chunks");
  return db.prepare(`SELECT chunk.record_json FROM discovery_chunks AS chunk JOIN discovery_extractions AS extraction ON extraction.id = chunk.discovery_extraction_id WHERE extraction.discovery_case_id = ? ORDER BY chunk.chunk_index`).all(caseId).map(parseRecordRow);
}

async function stageTrustedDiscoveryFile({ storageRoot, dbPath, payload = {} }) {
  await ensureSpine(storageRoot);
  if (payload.externalSecurityAcknowledged !== true) throw securityGateError("EXTERNAL_SECURITY_ACKNOWLEDGMENT_REQUIRED", "Confirm that security checking is handled outside Project State before adding files.");
  const actorId = requiredDiscoveryId(payload.actorId, "Staging actor ID");
  const reason = requiredDiscoveryText(payload.reason, "External security acknowledgment reason");
  const sourcePath = path.resolve(requiredDiscoveryText(payload.path || payload.localPath, "Selected file path"));
  if (!fs.existsSync(sourcePath) || !fs.statSync(sourcePath).isFile()) throw new Error("Selected file does not exist or is not a file.");
  const stat = fs.statSync(sourcePath);
  if (stat.size > MAX_IMPORT_FILE_BYTES) throw new Error("Selected file exceeds the configured import size limit.");
  const extension = path.extname(sourcePath).toLowerCase();
  if (!IMPORT_FILE_EXTENSIONS.has(extension)) throw new Error("Selected file type is not supported for Discovery.");
  const timestamp = requiredDiscoveryTimestamp(payload.timestamp || nowIso(), "Staging timestamp");
  const discoveryCaseId = payload.discoveryCaseId || makeId("discovery_case");
  const assetId = makeId("file_asset");
  const versionId = makeId("file_version");
  const stagedPath = path.join(storageRoot, "quarantine", assetId, versionId, safeFileName(path.basename(sourcePath)));
  await fsp.mkdir(path.dirname(stagedPath), { recursive: true });
  await fsp.copyFile(sourcePath, stagedPath, fs.constants.COPYFILE_EXCL);
  const stagedStat = fs.statSync(stagedPath);
  const sha256 = await checksumFile(stagedPath);
  const managedPath = relativeManagedPath(storageRoot, stagedPath);

  let caseCreated = false;
  const lookupDb = openDatabase(dbPath);
  try { caseCreated = !lookupDb.prepare("SELECT 1 AS found FROM discovery_cases WHERE id = ?").get(discoveryCaseId); }
  finally { lookupDb.close(); }
  if (caseCreated) await createDiscoveryCase({ storageRoot, dbPath, payload: { id: discoveryCaseId, createdBy: actorId, createdAt: timestamp, stage: "quarantine", status: "created", title: payload.caseTitle || path.basename(sourcePath) } });
  const registration = await registerDiscoveryFileVersion({ storageRoot, dbPath, payload: { fileAssetId: assetId, fileVersionId: versionId, sha256, byteSize: stagedStat.size, originalName: path.basename(sourcePath), managedPath, createdAt: timestamp, privacyClass: payload.privacyClass || "local_only", externalSecurityAcknowledged: true, externalSecurityAcknowledgedBy: actorId, externalSecurityAcknowledgedAt: timestamp, externalSecurityReason: reason } });
  const actualAsset = registration.fileAsset;
  const actualVersion = registration.fileVersion;
  if (registration.deduplicated && actualVersion.managedPath !== managedPath) await fsp.rm(path.dirname(stagedPath), { recursive: true, force: true });
  const membershipDb = openDatabase(dbPath);
  let membershipExists = false;
  try { membershipExists = Boolean(membershipDb.prepare("SELECT 1 AS found FROM discovery_case_files WHERE discovery_case_id = ? AND file_version_id = ?").get(discoveryCaseId, actualVersion.id)); }
  finally { membershipDb.close(); }
  if (!membershipExists) await attachDiscoveryFileVersion({ storageRoot, dbPath, payload: { id: makeId("discovery_file"), discoveryCaseId, fileAssetId: actualAsset.id, fileVersionId: actualVersion.id, addedAt: timestamp, groupingRationale: "User-selected trusted file staged for Discovery." } });
  await appendDiscoveryEvent({ storageRoot, dbPath, payload: { id: makeId("discovery_event"), discoveryCaseId, eventType: "external_security_responsibility_acknowledged", actorId, actorType: "human", occurredAt: timestamp, fileVersionId: actualVersion.id, reason } });
  return { ok: true, discoveryCaseId, caseCreated, fileAssetId: actualAsset.id, fileVersionId: actualVersion.id, sha256: actualVersion.sha256, deduplicated: registration.deduplicated, securityMode: "external_user_responsibility" };
}

async function extractDiscoveryFileVersion({ storageRoot, dbPath, payload = {} }) {
  await ensureSpine(storageRoot);
  const discoveryCaseId = requiredDiscoveryId(payload.discoveryCaseId, "Discovery Case ID");
  const fileVersionId = requiredDiscoveryId(payload.fileVersionId, "File Version ID");
  const actorId = requiredDiscoveryId(payload.actorId, "Extraction actor ID");
  const createdAt = requiredDiscoveryTimestamp(payload.createdAt || nowIso(), "Extraction createdAt");
  const db = openDatabase(dbPath);
  let version;
  try {
    if (!db.prepare("SELECT 1 AS found FROM discovery_case_files WHERE discovery_case_id = ? AND file_version_id = ?").get(discoveryCaseId, fileVersionId)) throw new Error("File Version is not attached to the Discovery Case.");
    version = dbRecord(db, "file_versions", fileVersionId);
    if (!version) throw new Error("File Version was not found.");
  } finally { db.close(); }
  await authorizeDiscoveryContentAccess({ storageRoot, dbPath, reference: { managedPath: version.managedPath } });
  const extension = path.extname(version.originalName || "").toLowerCase();
  const extractionId = payload.id || makeId("discovery_extraction");
  let status = "unsupported";
  let text = "";
  let error = null;
  try {
    if ([".txt", ".md", ".csv", ".json", ".pdf", ".docx"].includes(extension)) {
      text = cleanExtractedText(await extractText(resolveManagedPath(storageRoot, version.managedPath)) || "");
      status = text ? "complete" : "partial";
    } else if ([".png", ".jpg", ".jpeg", ".webp", ".gif"].includes(extension)) status = "metadata_only";
  } catch (caught) {
    status = "failed";
    error = { name: caught.name || "Error", message: caught.message || "Extraction failed." };
  }
  let textPath = "";
  let textSha256 = "";
  let textBytes = 0;
  const chunks = [];
  if (text) {
    const extractionRoot = path.join(storageRoot, "discovery", discoveryCaseId, fileVersionId, extractionId);
    const fullTextPath = path.join(extractionRoot, "full-text.txt");
    await fsp.mkdir(extractionRoot, { recursive: true });
    await fsp.writeFile(fullTextPath, text, "utf8");
    textPath = relativeManagedPath(storageRoot, fullTextPath);
    textSha256 = checksumText(text);
    textBytes = Buffer.byteLength(text, "utf8");
    const pieces = chunkDeterministicText(text, Number(payload.chunkCharacters) || 4000);
    for (let index = 0; index < pieces.length; index += 1) {
      const chunkText = pieces[index];
      const chunkId = `${extractionId}_chunk_${String(index).padStart(4, "0")}`;
      const chunkPath = path.join(extractionRoot, "chunks", `${String(index).padStart(4, "0")}.txt`);
      await fsp.mkdir(path.dirname(chunkPath), { recursive: true });
      await fsp.writeFile(chunkPath, chunkText, "utf8");
      chunks.push({ id: chunkId, discoveryExtractionId: extractionId, chunkIndex: index, textPath: relativeManagedPath(storageRoot, chunkPath), textSha256: checksumText(chunkText), textBytes: Buffer.byteLength(chunkText, "utf8") });
    }
  }
  const record = { id: extractionId, discoveryCaseId, fileAssetId: version.fileAssetId, fileVersionId, sourceSha256: version.sha256, status, extractorId: "project_state_deterministic_v0.1", textPath, textSha256, textBytes, chunkCount: chunks.length, createdAt, error };
  const writeDb = openDatabase(dbPath);
  try {
    writeDb.exec("BEGIN IMMEDIATE TRANSACTION");
    insertStrict(writeDb, "discovery_extractions", { id: extractionId, discovery_case_id: discoveryCaseId, file_asset_id: version.fileAssetId, file_version_id: fileVersionId, source_sha256: version.sha256, status, extractor_id: record.extractorId, text_path: textPath || null, text_sha256: textSha256 || null, text_bytes: textBytes, created_at: createdAt, record_json: JSON.stringify(record) });
    for (const chunk of chunks) insertStrict(writeDb, "discovery_chunks", { id: chunk.id, discovery_extraction_id: extractionId, chunk_index: chunk.chunkIndex, text_path: chunk.textPath, text_sha256: chunk.textSha256, text_bytes: chunk.textBytes, record_json: JSON.stringify(chunk) });
    writeDb.exec("COMMIT");
  } catch (caught) { try { writeDb.exec("ROLLBACK"); } catch {} throw caught; }
  finally { writeDb.close(); }
  await appendDiscoveryEvent({ storageRoot, dbPath, payload: { id: makeId("discovery_event"), discoveryCaseId, eventType: "deterministic_extraction_completed", actorId, actorType: "tool", occurredAt: createdAt, fileVersionId, extractionId, status, chunkCount: chunks.length } });
  return { ok: status !== "failed", extraction: record, chunks };
}

async function readDiscoveryExtractionText({ storageRoot, dbPath, payload = {} }) {
  const extractionId = requiredDiscoveryId(payload.extractionId || payload.id, "Discovery Extraction ID");
  const db = openDatabase(dbPath);
  let extraction;
  let version;
  try { extraction = dbRecord(db, "discovery_extractions", extractionId); if (!extraction) throw new Error("Discovery Extraction was not found."); version = dbRecord(db, "file_versions", extraction.fileVersionId); }
  finally { db.close(); }
  await authorizeDiscoveryContentAccess({ storageRoot, dbPath, reference: { managedPath: version.managedPath } });
  if (!extraction.textPath) return { ok: true, status: extraction.status, text: "" };
  const text = await fsp.readFile(resolveManagedPath(storageRoot, extraction.textPath), "utf8");
  if (Buffer.byteLength(text, "utf8") !== extraction.textBytes || checksumText(text) !== extraction.textSha256) throw new Error("Discovery Extraction derivative integrity failed.");
  return { ok: true, status: extraction.status, text };
}

function chunkDeterministicText(text, targetCharacters) {
  const limit = Math.max(500, Math.min(16000, Number(targetCharacters) || 4000));
  const chunks = [];
  let remaining = String(text || "");
  while (remaining.length > limit) {
    let splitAt = remaining.lastIndexOf("\n", limit);
    if (splitAt < Math.floor(limit * 0.5)) splitAt = remaining.lastIndexOf(" ", limit);
    if (splitAt < Math.floor(limit * 0.5)) splitAt = limit;
    chunks.push(remaining.slice(0, splitAt).trim());
    remaining = remaining.slice(splitAt).trimStart();
  }
  if (remaining.trim()) chunks.push(remaining.trim());
  return chunks;
}

const DISCOVERY_DESTINATIONS = new Set(["existing_project", "additional_project_link", "proposed_new_project", "general_reference", "orphaned_idea", "unassigned", "rejected"]);

async function analyzeDiscoveryCase({ storageRoot, dbPath, payload = {} }) {
  await ensureSpine(storageRoot);
  const discoveryCaseId = requiredDiscoveryId(payload.discoveryCaseId, "Discovery Case ID");
  const actorId = requiredDiscoveryId(payload.actorId || "project_state_deterministic", "Discovery analysis actor ID");
  const createdAt = requiredDiscoveryTimestamp(payload.createdAt || nowIso(), "Discovery analysis createdAt");
  const db = openDatabase(dbPath);
  let versions;
  let projects;
  try {
    if (!dbRecord(db, "discovery_cases", discoveryCaseId)) throw new Error("Discovery Case was not found.");
    versions = db.prepare(`SELECT version.record_json FROM file_versions AS version JOIN discovery_case_files AS membership ON membership.file_version_id = version.id WHERE membership.discovery_case_id = ? ORDER BY membership.rowid`).all(discoveryCaseId).map(parseRecordRow);
    projects = readRecordJson(db, "projects");
  } finally { db.close(); }
  if (!versions.length) throw new Error("Discovery Case has no File Versions to analyze.");
  const baseNames = versions.map((version) => path.basename(version.originalName || "", path.extname(version.originalName || ""))).filter(Boolean);
  const suggestedName = suggestDiscoveryName(baseNames) || "Unassigned material";
  const suggestionTokens = tokenSet(suggestedName);
  const projectCandidates = projects.map((project) => {
    const projectTokens = tokenSet(project.name || "");
    const overlap = [...suggestionTokens].filter((token) => projectTokens.has(token));
    return { projectId: project.id, name: project.name || "", confidence: suggestionTokens.size ? Number((overlap.length / suggestionTokens.size).toFixed(2)) : 0, evidence: overlap };
  }).filter((candidate) => candidate.confidence > 0).sort((a, b) => b.confidence - a.confidence || a.name.localeCompare(b.name)).slice(0, 5);
  const questions = [];
  if (projectCandidates.length) questions.push({ id: "routing_existing_project", text: `Does this belong to ${projectCandidates[0].name}?`, affects: "routing", allowNotSure: true });
  else questions.push({ id: "routing_new_or_unassigned", text: "Should this become a new project, general reference, an orphaned idea, or remain unassigned?", affects: "routing", allowNotSure: true });
  if (versions.length > 1) questions.push({ id: "grouping_confirmation", text: "Do these files belong together as one Discovery case?", affects: "grouping", allowNotSure: true });
  questions.push({ id: "privacy_confirmation", text: "Should this material remain local-only, or may a configured provider receive selected content later?", affects: "privacy", allowNotSure: true });
  const suggestion = { suggestedProjectNames: [{ name: suggestedName, confidence: baseNames.length === 1 ? 0.65 : 0.55, evidence: baseNames }], projectCandidates, questions, deterministic: true, provider: "project_state_local_rules_v0.1" };
  await appendDiscoveryInteraction({ storageRoot, dbPath, payload: { id: makeId("interaction"), discoveryCaseId, actorId, actorType: "tool", interactionType: "machine_suggestion", createdAt, content: suggestion, evidence: versions.map((version) => ({ fileVersionId: version.id, sha256: version.sha256 })) } });
  for (const question of questions) await appendDiscoveryInteraction({ storageRoot, dbPath, payload: { id: makeId("interaction"), discoveryCaseId, actorId, actorType: "tool", interactionType: "system_question", createdAt, content: question } });
  await updateDiscoveryCaseRecord({ dbPath, discoveryCaseId, changes: { stage: "questions", status: "questioning", updatedAt: createdAt, suggestedName } });
  await appendDiscoveryEvent({ storageRoot, dbPath, payload: { id: makeId("discovery_event"), discoveryCaseId, eventType: "deterministic_discovery_completed", actorId, actorType: "tool", occurredAt: createdAt, suggestedName, projectCandidateCount: projectCandidates.length, questionCount: questions.length } });
  return { ok: true, discoveryCaseId, ...suggestion };
}

async function recordDiscoveryAnswer({ storageRoot, dbPath, payload = {} }) {
  const discoveryCaseId = requiredDiscoveryId(payload.discoveryCaseId, "Discovery Case ID");
  const actorId = requiredDiscoveryId(payload.actorId, "Answering actor ID");
  const createdAt = requiredDiscoveryTimestamp(payload.createdAt || nowIso(), "Discovery answer createdAt");
  const questionId = requiredDiscoveryId(payload.questionId, "Discovery question ID");
  const answer = payload.answer === null || payload.answer === undefined || String(payload.answer).trim() === "" ? "Not sure" : payload.answer;
  const interaction = await appendDiscoveryInteraction({ storageRoot, dbPath, payload: { id: payload.id || makeId("interaction"), discoveryCaseId, actorId, actorType: "human", interactionType: payload.correction ? "user_correction" : "user_answer", createdAt, questionId, content: answer, supersedesInteractionId: payload.supersedesInteractionId || null } });
  await appendDiscoveryEvent({ storageRoot, dbPath, payload: { id: makeId("discovery_event"), discoveryCaseId, eventType: payload.correction ? "answer_corrected" : "answer_recorded", actorId, actorType: "human", occurredAt: createdAt, interactionId: interaction.interaction.id, questionId } });
  return interaction;
}

async function confirmDiscoveryRouting({ storageRoot, dbPath, payload = {} }) {
  const discoveryCaseId = requiredDiscoveryId(payload.discoveryCaseId, "Discovery Case ID");
  const actorId = requiredDiscoveryId(payload.actorId, "Routing actor ID");
  const confirmedAt = requiredDiscoveryTimestamp(payload.confirmedAt || nowIso(), "Routing confirmedAt");
  const destination = String(payload.destination || "");
  if (!DISCOVERY_DESTINATIONS.has(destination)) throw new Error("Discovery routing destination is not supported.");
  const projectId = payload.projectId ? requiredDiscoveryId(payload.projectId, "Routing project ID") : null;
  if (destination === "existing_project" && !projectId) throw new Error("Existing-project routing requires a project ID.");
  const additionalProjectIds = Array.isArray(payload.additionalProjectIds) ? [...new Set(payload.additionalProjectIds.map((id) => requiredDiscoveryId(id, "Additional project ID")))] : [];
  const db = openDatabase(dbPath);
  try {
    if (!dbRecord(db, "discovery_cases", discoveryCaseId)) throw new Error("Discovery Case was not found.");
    for (const id of [projectId, ...additionalProjectIds].filter(Boolean)) if (!db.prepare("SELECT 1 AS found FROM projects WHERE id = ?").get(id)) throw new Error(`Routing project was not found: ${id}`);
  } finally { db.close(); }
  const routing = { destination, projectId, additionalProjectIds, proposedProjectName: String(payload.proposedProjectName || "").trim(), confirmedBy: actorId, confirmedAt };
  if (destination === "proposed_new_project" && !routing.proposedProjectName) throw new Error("New-project routing requires a proposed project name.");
  const interaction = await appendDiscoveryInteraction({ storageRoot, dbPath, payload: { id: payload.id || makeId("interaction"), discoveryCaseId, actorId, actorType: "human", interactionType: "routing_confirmation", createdAt: confirmedAt, content: routing } });
  await updateDiscoveryCaseRecord({ dbPath, discoveryCaseId, changes: { stage: "routing", status: "ready_for_intake", updatedAt: confirmedAt, confirmedProjectId: projectId, confirmedRouting: routing, routingInteractionId: interaction.interaction.id } });
  await appendDiscoveryEvent({ storageRoot, dbPath, payload: { id: makeId("discovery_event"), discoveryCaseId, eventType: "routing_confirmed", actorId, actorType: "human", occurredAt: confirmedAt, destination, projectId, interactionId: interaction.interaction.id } });
  return { ok: true, discoveryCaseId, routing, interactionId: interaction.interaction.id };
}

async function getDiscoveryCase({ storageRoot, dbPath, payload = {} }) {
  const discoveryCaseId = requiredDiscoveryId(payload.discoveryCaseId || payload.id, "Discovery Case ID");
  const state = await readDiscoveryFoundationState({ storageRoot, dbPath, payload: { discoveryCaseId } });
  if (!state.discoveryCases.length) throw new Error("Discovery Case was not found.");
  const memberVersionIds = new Set(state.caseFiles.map((item) => item.fileVersionId));
  return { ok: true, discoveryCase: state.discoveryCases[0], fileAssets: state.fileAssets.filter((asset) => state.fileVersions.some((version) => memberVersionIds.has(version.id) && version.fileAssetId === asset.id)), fileVersions: state.fileVersions.filter((version) => memberVersionIds.has(version.id)), memberships: state.caseFiles, extractions: state.extractions, chunks: state.chunks, interactions: state.interactions, events: state.events };
}

async function updateDiscoveryCaseRecord({ dbPath, discoveryCaseId, changes = {} }) {
  const db = openDatabase(dbPath);
  try {
    const current = dbRecord(db, "discovery_cases", discoveryCaseId);
    if (!current) throw new Error("Discovery Case was not found.");
    const next = { ...current, ...cloneJson(changes) };
    if (!DISCOVERY_STAGES.has(next.stage) || !DISCOVERY_CASE_STATUSES.has(next.status)) throw new Error("Discovery Case state is not supported.");
    db.prepare("UPDATE discovery_cases SET updated_at = ?, stage = ?, status = ?, confirmed_project_id = ?, record_json = ? WHERE id = ?").run(next.updatedAt || nowIso(), next.stage, next.status, next.confirmedProjectId || null, JSON.stringify(next), discoveryCaseId);
    return next;
  } finally { db.close(); }
}

function suggestDiscoveryName(baseNames) {
  if (!baseNames.length) return "";
  if (baseNames.length === 1) return titleFromTokens(baseNames[0]);
  const tokenLists = baseNames.map((name) => [...tokenSet(name)]);
  const common = tokenLists[0].filter((token) => tokenLists.every((list) => list.includes(token)));
  return titleFromTokens(common.length ? common.join(" ") : baseNames[0]);
}

function tokenSet(value) {
  return new Set(String(value || "").toLowerCase().replace(/[_-]+/g, " ").replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter((token) => token.length > 1 && !["the", "and", "for", "with", "from", "file", "document"].includes(token)));
}

function titleFromTokens(value) {
  return String(value || "").replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim().replace(/\b\w/g, (letter) => letter.toUpperCase());
}

async function promoteDiscoveryToIntake({ storageRoot, dbPath, payload = {} }) {
  const discoveryCaseId = requiredDiscoveryId(payload.discoveryCaseId, "Discovery Case ID");
  const actorId = requiredDiscoveryId(payload.actorId, "Promoting actor ID");
  const promotedAt = requiredDiscoveryTimestamp(payload.promotedAt || nowIso(), "Discovery promotion timestamp");
  const reason = requiredDiscoveryText(payload.reason, "Discovery promotion reason");
  const caseView = await getDiscoveryCase({ storageRoot, dbPath, payload: { discoveryCaseId } });
  const discoveryCase = caseView.discoveryCase;
  if (discoveryCase.status === "promoted" && discoveryCase.promotedIntakeBatchId) return { ok: true, deduplicated: true, discoveryCaseId, intakeBatchId: discoveryCase.promotedIntakeBatchId, intakeItemIds: discoveryCase.promotedIntakeItemIds || [] };
  if (discoveryCase.status !== "ready_for_intake" || !discoveryCase.confirmedRouting || !discoveryCase.routingInteractionId) throw new Error("Discovery Case is not ready for Intake promotion.");
  const routing = discoveryCase.confirmedRouting;
  if (["unassigned", "rejected"].includes(routing.destination)) throw new Error(`Discovery destination ${routing.destination} cannot be promoted to Intake.`);
  for (const version of caseView.fileVersions) await authorizeDiscoveryContentAccess({ storageRoot, dbPath, reference: { managedPath: version.managedPath } });
  const intakeBatchId = payload.intakeBatchId || makeId("intake_batch");
  const intakeItems = [];
  const targetProjectIds = [...new Set([routing.projectId, ...(routing.additionalProjectIds || [])].filter(Boolean))];
  for (const version of caseView.fileVersions) {
    const extraction = (caseView.extractions || []).find((item) => item.fileVersionId === version.id && item.textPath) || null;
    let extractedText = "";
    if (extraction) extractedText = (await readDiscoveryExtractionText({ storageRoot, dbPath, payload: { extractionId: extraction.id } })).text || "";
    const sourceTitle = path.basename(version.originalName || "Discovery source", path.extname(version.originalName || "")) || version.originalName || "Discovery source";
    for (const projectId of (targetProjectIds.length ? targetProjectIds : [null])) intakeItems.push({
      id: makeId("intake_item"),
      intakeBatchId,
      projectId: projectId || "",
      status: "pending",
      reviewState: "needs_review",
      queueState: "new",
      queueNotes: "",
      title: `Add source: ${version.originalName || sourceTitle}`,
      createdAt: promotedAt,
      createdBy: actorId,
      sourceLabel: `Discovery: ${version.originalName || sourceTitle}`,
      armType: "discovery",
      proposedObjectType: "Source",
      proposedChange: {
        text: sourceTitle,
        summary: extractedText.slice(0, 2000),
        extractionStatus: extraction?.status || "metadata_only"
      },
      evidence: {
        discoveryCaseId,
        fileAssetId: version.fileAssetId,
        fileVersionId: version.id,
        sourceSha256: version.sha256,
        extractionId: extraction?.id || "",
        managedFile: {
          fileName: version.originalName || sourceTitle,
          managedPath: version.managedPath,
          sha256: version.sha256,
          size: version.byteSize || 0,
          contentType: ""
        }
      },
      discoveryCaseId,
      fileAssetId: version.fileAssetId,
      fileVersionId: version.id,
      sourceSha256: version.sha256,
      originalName: version.originalName,
      destination: routing.destination,
      proposedProjectName: routing.proposedProjectName || "",
      routingInteractionId: discoveryCase.routingInteractionId,
      proposedBy: actorId,
      proposedAt: promotedAt,
      reason,
      approval: null,
      assignments: [],
      comments: [],
      archived: false
    });
  }
  const batch = { id: intakeBatchId, status: "pending", createdAt: promotedAt, createdBy: actorId, reason, origin: "discovery", discoveryCaseId, routingInteractionId: discoveryCase.routingInteractionId, destination: routing.destination, itemIds: intakeItems.map((item) => item.id) };
  const db = openDatabase(dbPath);
  try {
    db.exec("BEGIN IMMEDIATE TRANSACTION");
    insertStrict(db, "intake_batches", { id: batch.id, status: batch.status, created_at: batch.createdAt, record_json: JSON.stringify(batch) });
    for (const item of intakeItems) insertStrict(db, "intake_items", { id: item.id, project_id: item.projectId, status: item.status, arm_type: item.armType, proposed_object_type: item.proposedObjectType, record_json: JSON.stringify(item) });
    if (routing.destination === "proposed_new_project") {
      const proposedProjectId = makeId("proposed_project");
      const proposed = { id: proposedProjectId, intakeBatchId, name: routing.proposedProjectName, status: "pending", discoveryCaseId, proposedBy: actorId, proposedAt: promotedAt, sourceIntakeItemIds: intakeItems.map((item) => item.id) };
      insertStrict(db, "proposed_projects", { id: proposed.id, intake_batch_id: intakeBatchId, status: proposed.status, record_json: JSON.stringify(proposed) });
      batch.proposedProjectId = proposedProjectId;
      db.prepare("UPDATE intake_batches SET record_json = ? WHERE id = ?").run(JSON.stringify(batch), intakeBatchId);
    }
    db.exec("COMMIT");
  } catch (error) { try { db.exec("ROLLBACK"); } catch {} throw error; }
  finally { db.close(); }
  await updateDiscoveryCaseRecord({ dbPath, discoveryCaseId, changes: { stage: "intake", status: "promoted", updatedAt: promotedAt, promotedIntakeBatchId: intakeBatchId, promotedIntakeItemIds: intakeItems.map((item) => item.id) } });
  await appendDiscoveryEvent({ storageRoot, dbPath, payload: { id: makeId("discovery_event"), discoveryCaseId, eventType: "promoted_to_intake", actorId, actorType: "human", occurredAt: promotedAt, intakeBatchId, intakeItemIds: intakeItems.map((item) => item.id), reason } });
  return { ok: true, deduplicated: false, discoveryCaseId, intakeBatchId, intakeItemIds: intakeItems.map((item) => item.id), destination: routing.destination, coreChanged: false };
}

async function authorizeDiscoveryContentAccess({ storageRoot, dbPath, reference = {} }) {
  await ensureSpine(storageRoot);
  const suppliedPath = reference?.managedPath
    ? resolveManagedPath(storageRoot, reference.managedPath)
    : pathFromFileLike(reference?.path || reference?.localPath || reference);
  if (!suppliedPath) return { ok: true, governed: false, reason: "non-path file reference" };

  const quarantineRoot = path.resolve(storageRoot, "quarantine");
  const resolvedPath = path.resolve(suppliedPath);
  if (resolvedPath !== quarantineRoot && !resolvedPath.startsWith(`${quarantineRoot}${path.sep}`)) {
    return { ok: true, governed: false, reason: "outside Discovery quarantine" };
  }

  const managedPath = relativeManagedPath(storageRoot, resolvedPath);
  const db = openDatabase(dbPath);
  try {
    const versionRow = db.prepare("SELECT id, file_asset_id, sha256, byte_size, record_json FROM file_versions WHERE managed_path = ?").get(managedPath);
    if (!versionRow) throw securityGateError("FILE_VERSION_MISMATCH", "Quarantined content is not registered as a File Version.");
    if (!fs.existsSync(resolvedPath) || !fs.statSync(resolvedPath).isFile()) {
      throw securityGateError("FILE_VERSION_MISMATCH", "Registered quarantined content is missing.");
    }
    const stat = fs.statSync(resolvedPath);
    if (stat.size !== versionRow.byte_size || await checksumFile(resolvedPath) !== versionRow.sha256) {
      throw securityGateError("FILE_VERSION_MISMATCH", "Quarantined content no longer matches its immutable File Version.");
    }
    const version = JSON.parse(versionRow.record_json);
    if (version.externalSecurityAcknowledged === true && version.externalSecurityAcknowledgedBy && version.externalSecurityAcknowledgedAt) {
      return { ok: true, governed: true, fileAssetId: versionRow.file_asset_id, fileVersionId: versionRow.id, sha256: versionRow.sha256, securityMode: "external_user_responsibility", acknowledgedBy: version.externalSecurityAcknowledgedBy, acknowledgedAt: version.externalSecurityAcknowledgedAt };
    }
    const receipt = db.prepare(`
      SELECT id, sha256, verdict, eligible, provider_id, completed_at
      FROM security_receipts
      WHERE file_version_id = ? AND file_asset_id = ?
      ORDER BY rowid DESC
      LIMIT 1
    `).get(versionRow.id, versionRow.file_asset_id);
    if (!receipt) throw securityGateError("SECURITY_RECEIPT_STALE", "No Security Receipt exists for this File Version.");
    if (receipt.sha256 !== versionRow.sha256) throw securityGateError("FILE_VERSION_MISMATCH", "Security Receipt checksum does not match the File Version.");
    if (receipt.verdict !== "clean" || receipt.eligible !== 1) {
      const errorCode = receipt.verdict === "threat_detected"
        ? "THREAT_DETECTED"
        : receipt.verdict === "suspicious"
          ? "VERDICT_SUSPICIOUS"
          : receipt.verdict === "unknown"
            ? "VERDICT_UNKNOWN"
            : "SCAN_FAILED";
      throw securityGateError(errorCode, `Security Receipt verdict does not permit content access: ${receipt.verdict}.`);
    }
    return {
      ok: true,
      governed: true,
      fileAssetId: versionRow.file_asset_id,
      fileVersionId: versionRow.id,
      sha256: versionRow.sha256,
      receiptId: receipt.id,
      providerId: receipt.provider_id,
      completedAt: receipt.completed_at
    };
  } finally {
    db.close();
  }
}

function securityGateError(code, message) {
  const error = new Error(message);
  error.code = code;
  return error;
}

function resolveDiscoveryReadReference(storageRoot, reference) {
  if (reference?.managedPath) return resolveManagedPath(storageRoot, reference.managedPath);
  return reference;
}

async function loadStore({ storageRoot, dbPath }) {
  await ensureSpine(storageRoot);
  if (!fs.existsSync(dbPath)) return { source: "desktop-spine", store: null, raw: "", meta: null };
  const db = openDatabase(dbPath);
  try {
    const metaRecord = readMeta(db, "store");
    if (!metaRecord) return { source: "desktop-spine", store: null, raw: "", meta: null };
    const integrity = await verifyIntegrity({ storageRoot, dbPath, preserveOnFailure: false });
    if (!integrity.ok) throw new Error(`Desktop spine integrity check failed: ${integrity.errors.join("; ")}`);
    const split = readSplitRecords(db);
    const store = await rebuildStoreFromSplitRecords(storageRoot, split);
    const manifest = readMeta(db, "manifest") || {};
    return {
      source: "desktop-spine",
      store,
      raw: JSON.stringify(store),
      meta: manifest
    };
  } catch (error) {
    const snapshot = readMeta(db, "snapshot");
    await preserveRecoveryRecordWithOpenDb(db, storageRoot, {
      stage: "desktop-load",
      message: error.message,
      stack: error.stack || "",
      raw: snapshot?.store ? JSON.stringify(snapshot.store) : ""
    });
    if (snapshot?.store) {
      return {
        source: "desktop-spine-snapshot-recovery",
        store: snapshot.store,
        raw: JSON.stringify(snapshot.store),
        meta: readMeta(db, "manifest") || null
      };
    }
    throw error;
  } finally {
    db.close();
  }
}

async function saveStore({ storageRoot, dbPath, payload }) {
  await ensureSpine(storageRoot);
  let store = payload.store || {};
  let manifest = payload.manifest || {};
  const db = openDatabase(dbPath);
  if (payload.preserveConcurrentApiIntake !== false) store = mergePersistedApiArmIntake(db, store);
  manifest = {
    ...manifest,
    counts: {
      ...(manifest.counts || {}),
      intakeBatches: (store.intakeBatches || []).length,
      intakeItems: (store.intakeItems || []).length
    }
  };
  const split = payload.split || splitStoreRecordsForBridge(store, manifest);
  const splitMeta = Array.isArray(split.meta) ? split.meta[0] : split.meta;
  splitMeta.intakeBatches = store.intakeBatches || [];
  splitMeta.intakeItems = store.intakeItems || [];
  const snapshot = JSON.stringify(store);
  let committed = false;

  try {
    db.exec("BEGIN IMMEDIATE TRANSACTION");
    clearWritableTables(db);
    writeMeta(db, "manifest", manifest);
    writeMeta(db, "store", splitMeta || {});
    writeMeta(db, "snapshot", { store, snapshotBytes: Buffer.byteLength(snapshot, "utf8") });

    writeActors(db, splitMeta?.actors || store.actors || []);
    writeIntakeBatches(db, splitMeta?.intakeBatches || store.intakeBatches || []);
    writeIntakeItems(db, splitMeta?.intakeItems || store.intakeItems || []);
    writeProjects(db, split.projects || []);
    writeProjectChildren(db, split.projects || []);
    writeHistory(db, split.history || []);
    writeSources(db, split.sources || []);
    await writeExtracts(db, storageRoot, split.extracts || []);
    await writeAttachments(db, storageRoot, split.attachments || []);
    writeDrafts(db, split.drafts || []);
    writeSourceLinks(db, store);

    const manifestPath = await writeManifestFile(storageRoot, manifest, store);
    writeMeta(db, "latest_manifest_file", { path: manifestPath });
    db.exec("COMMIT");
    committed = true;
    const integrity = await verifyIntegrity({ storageRoot, dbPath, preserveOnFailure: true });
    if (!integrity.ok) throw new Error(`Desktop spine integrity check failed after save: ${integrity.errors.join("; ")}`);
    return { ok: true, source: "desktop-spine", manifestPath, integrity };
  } catch (error) {
    if (!committed) {
      try {
        db.exec("ROLLBACK");
      } catch {}
    }
    const issue = {
      stage: "desktop-save",
      message: error.message,
      stack: error.stack || "",
      raw: snapshot
    };
    await preserveRecoveryRecordWithOpenDb(db, storageRoot, issue);
    throw error;
  } finally {
    db.close();
  }
}

function mergePersistedApiArmIntake(db, incomingStore = {}) {
  const incomingBatches = Array.isArray(incomingStore.intakeBatches) ? incomingStore.intakeBatches : [];
  const incomingItems = Array.isArray(incomingStore.intakeItems) ? incomingStore.intakeItems : [];
  const persistedBatches = readRecordJson(db, "intake_batches");
  const persistedApiItems = readRecordJson(db, "intake_items").filter((item) => item.apiArmSubmissionId || item.intakeBatchId);
  return {
    ...incomingStore,
    intakeBatches: mergeRecordsById(persistedBatches, incomingBatches),
    intakeItems: mergeRecordsById(persistedApiItems, incomingItems)
  };
}

function mergeRecordsById(persisted = [], incoming = []) {
  const incomingIds = new Set(incoming.map((record) => record?.id).filter(Boolean));
  return [...incoming, ...persisted.filter((record) => record?.id && !incomingIds.has(record.id))];
}

async function importBrowserExport({ storageRoot, dbPath, payload = {} }) {
  await ensureSpine(storageRoot);
  const raw = browserExportRawText(payload);
  let parsed = null;
  let stagingRoot = "";

  try {
    parsed = browserExportParsedPayload(payload, raw);
    const store = extractStoreFromBrowserExport(parsed);
    const validation = validateMigrationStore(store);
    if (validation.errors.length) {
      await preserveRecoveryRecord({
        storageRoot,
        dbPath,
        issue: {
          stage: "browser-json-import-validation",
          message: "Browser export failed migration validation.",
          raw: JSON.stringify({ errors: validation.errors, exportSummary: describeBrowserExport(parsed) }, null, 2)
        }
      });
      throw new Error(`Browser export failed migration validation: ${validation.errors.join("; ")}`);
    }

    await preserveRecoveryRecord({
      storageRoot,
      dbPath,
      issue: {
        stage: "browser-json-import-source",
        message: "Browser JSON export preserved before desktop spine import.",
        raw
      }
    });

    const manifest = buildMigrationManifest(store, {
      source: describeBrowserExport(parsed),
      reason: payload.reason || "",
      actorId: payload.actorId || "",
      sourceFile: payload.sourceFile || ""
    });
    const split = splitStoreRecordsForBridge(store, manifest);
    const snapshot = JSON.stringify(store);

    stagingRoot = path.join(storageRoot, "temp", `browser-json-import-${safeStamp()}-${crypto.randomBytes(3).toString("hex")}`);
    const stagingDbPath = path.join(stagingRoot, DATABASE_FILE);
    const stagingSave = await saveStore({
      storageRoot: stagingRoot,
      dbPath: stagingDbPath,
      payload: { store, manifest, split, snapshot, preserveConcurrentApiIntake: false }
    });
    if (!stagingSave.integrity?.ok) throw new Error("Browser export failed staging integrity verification.");

    const liveSave = await saveStore({
      storageRoot,
      dbPath,
      payload: { store, manifest, split, snapshot, preserveConcurrentApiIntake: false }
    });
    const loaded = await loadStore({ storageRoot, dbPath });
    const afterValidation = validateMigrationStore(loaded.store);
    if (afterValidation.errors.length) {
      throw new Error(`Desktop spine import verification failed: ${afterValidation.errors.join("; ")}`);
    }

    return {
      ok: true,
      source: "browser-json-import",
      importedAt: manifest.importedAt,
      counts: manifest.counts,
      idCount: validation.idCount,
      historyCount: manifest.counts.changes,
      sourceLinksPreserved: validation.sourceLinks,
      liveIntegrity: liveSave.integrity || null
    };
  } catch (error) {
    await preserveRecoveryRecord({
      storageRoot,
      dbPath,
      issue: {
        stage: "browser-json-import",
        message: error.message,
        stack: error.stack || "",
        raw: raw || JSON.stringify(payload || {}, null, 2)
      }
    });
    throw error;
  } finally {
    if (stagingRoot) await fsp.rm(stagingRoot, { recursive: true, force: true });
  }
}

async function createBackupPackage({ storageRoot, dbPath, payload = {} }) {
  await ensureSpine(storageRoot);
  const actor = String(payload.actorId || payload.actorName || payload.actor || "").trim();
  const reason = String(payload.reason || "").trim();
  const timestamp = String(payload.timestamp || nowIso()).trim();
  if (!actor) throw new Error("Backup package requires an actor.");
  if (!reason) throw new Error("Backup package requires a reason.");
  if (!timestamp || Number.isNaN(Date.parse(timestamp))) throw new Error("Backup package requires a valid timestamp.");

  const integrity = await verifyIntegrity({ storageRoot, dbPath, preserveOnFailure: true });
  if (!integrity.ok) throw new Error(`Backup package blocked by integrity errors: ${integrity.errors.join("; ")}`);

  const packageId = payload.id || makeId("backup");
  const packageName = safeFileName(`project-state-backup-package-${timestamp.replace(/[:.]/g, "-")}-${packageId}`);
  const packagePath = path.join(storageRoot, "backups", packageName);
  const managedPath = path.join(packagePath, "managed");
  await fsp.rm(packagePath, { recursive: true, force: true });
  await fsp.mkdir(managedPath, { recursive: true });

  const dbSnapshotPath = path.join(packagePath, DATABASE_FILE);
  await writeDatabaseSnapshot(dbPath, dbSnapshotPath);

  const managedFiles = [];
  for (const folder of BACKUP_MANAGED_FOLDERS) {
    const sourceFolder = path.join(storageRoot, folder);
    const targetFolder = path.join(managedPath, folder);
    if (!fs.existsSync(sourceFolder)) continue;
    await fsp.cp(sourceFolder, targetFolder, { recursive: true, force: true });
    const files = await listPackageFiles(targetFolder);
    for (const filePath of files) {
      managedFiles.push({
        role: folder,
        path: relativeManagedPath(packagePath, filePath),
        bytes: fs.statSync(filePath).size,
        checksum: await checksumFile(filePath)
      });
    }
  }

  const dbStat = fs.statSync(dbSnapshotPath);
  const manifest = {
    app: "Project State",
    packageType: "desktop-backup-package",
    packageVersion: "0.1",
    packageId,
    createdAt: timestamp,
    createdBy: actor,
    actorId: payload.actorId || "",
    actorName: payload.actorName || payload.actor || "",
    reason,
    storageEngine: "sqlite-plus-managed-folders",
    database: {
      fileName: DATABASE_FILE,
      path: DATABASE_FILE,
      bytes: dbStat.size,
      checksum: await checksumFile(dbSnapshotPath)
    },
    managedFolders: BACKUP_MANAGED_FOLDERS,
    managedFiles,
    sourceIntegrity: integrity,
    sourceStorageRoot: storageRoot
  };
  const manifestPath = path.join(packagePath, "manifest.json");
  await fsp.writeFile(manifestPath, JSON.stringify(manifest, null, 2), "utf8");

  return {
    ok: true,
    source: "desktop-backup-package",
    packageId,
    packagePath,
    manifestPath,
    dbSnapshotPath,
    manifest
  };
}

async function restoreBackupPackage({ storageRoot, dbPath, payload = {} }) {
  await ensureSpine(storageRoot);
  const actor = String(payload.actorId || payload.actorName || payload.actor || "").trim();
  const reason = String(payload.reason || "").trim();
  const timestamp = String(payload.timestamp || nowIso()).trim();
  if (!actor) throw new Error("Restore package requires an actor.");
  if (!reason) throw new Error("Restore package requires a reason.");
  if (!timestamp || Number.isNaN(Date.parse(timestamp))) throw new Error("Restore package requires a valid timestamp.");

  const packagePath = path.resolve(String(payload.packagePath || payload.path || ""));
  if (!packagePath) throw new Error("Restore package requires a package path.");
  const validation = await validateBackupPackage({ packagePath });
  if (!validation.ok) throw new Error(`Restore package validation failed: ${validation.errors.join("; ")}`);

  const beforeIntegrity = await verifyIntegrity({ storageRoot, dbPath, preserveOnFailure: true });
  const recoverySnapshot = await preserveCurrentSpineForRestore({
    storageRoot,
    dbPath,
    actor,
    actorId: payload.actorId || "",
    actorName: payload.actorName || payload.actor || "",
    reason,
    timestamp,
    packagePath,
    beforeIntegrity
  });

  await replaceLiveSpineFromBackupPackage({ storageRoot, dbPath, packagePath, manifest: validation.manifest });
  const afterIntegrity = await verifyIntegrity({ storageRoot, dbPath, preserveOnFailure: true });
  if (!afterIntegrity.ok) {
    throw new Error(`Restored spine failed integrity: ${afterIntegrity.errors.join("; ")}`);
  }

  await preserveRecoveryRecord({
    storageRoot,
    dbPath,
    issue: {
      stage: "desktop-restore-complete",
      message: "Desktop backup package restored.",
      raw: JSON.stringify({
        restoredAt: timestamp,
        restoredBy: actor,
        actorId: payload.actorId || "",
        actorName: payload.actorName || payload.actor || "",
        reason,
        packagePath,
        packageId: validation.manifest.packageId || "",
        recoverySnapshot,
        afterIntegrity
      }, null, 2)
    }
  });

  return {
    ok: true,
    source: "desktop-backup-package-restore",
    restoredAt: timestamp,
    restoredBy: actor,
    reason,
    packagePath,
    packageId: validation.manifest.packageId || "",
    recoverySnapshot,
    integrity: afterIntegrity
  };
}

async function validateBackupPackage({ packagePath }) {
  const errors = [];
  if (!packagePath || !fs.existsSync(packagePath)) {
    return { ok: false, errors: ["Backup package folder does not exist."], manifest: null };
  }
  const manifestPath = path.join(packagePath, "manifest.json");
  if (!fs.existsSync(manifestPath)) {
    return { ok: false, errors: ["Backup package manifest is missing."], manifest: null };
  }

  let manifest = null;
  try {
    manifest = JSON.parse(await fsp.readFile(manifestPath, "utf8"));
  } catch (error) {
    return { ok: false, errors: [`Backup package manifest is not readable JSON: ${error.message}`], manifest: null };
  }

  if (manifest.app !== "Project State") errors.push("Backup package app mismatch.");
  if (manifest.packageType !== "desktop-backup-package") errors.push("Backup package type mismatch.");
  if (!manifest.createdBy) errors.push("Backup package missing createdBy.");
  if (!manifest.createdAt) errors.push("Backup package missing createdAt.");
  if (!manifest.reason) errors.push("Backup package missing reason.");

  const dbRelativePath = manifest.database?.path || DATABASE_FILE;
  let dbPath = "";
  try {
    dbPath = resolvePackagePath(packagePath, dbRelativePath);
  } catch (error) {
    errors.push(`Backup DB path is unsafe: ${error.message}`);
  }
  if (dbPath && !fs.existsSync(dbPath)) errors.push("Backup package DB snapshot is missing.");
  if (dbPath && fs.existsSync(dbPath) && manifest.database?.checksum && await checksumFile(dbPath) !== manifest.database.checksum) errors.push("Backup package DB checksum mismatch.");

  for (const folder of BACKUP_MANAGED_FOLDERS) {
    const folderPath = path.join(packagePath, "managed", folder);
    if (!fs.existsSync(folderPath)) errors.push(`Backup package missing managed folder ${folder}.`);
  }
  for (const file of manifest.managedFiles || []) {
    let filePath = "";
    try {
      filePath = resolvePackagePath(packagePath, file.path);
    } catch (error) {
      errors.push(`Managed file path is unsafe: ${file.path}: ${error.message}`);
      continue;
    }
    if (!fs.existsSync(filePath)) {
      errors.push(`Backup package missing managed file ${file.path}.`);
      continue;
    }
    if (file.checksum && await checksumFile(filePath) !== file.checksum) errors.push(`Managed file checksum mismatch: ${file.path}`);
  }

  if (dbPath && fs.existsSync(dbPath)) {
    let db = null;
    try {
      db = new DatabaseSync(dbPath, { readOnly: true });
      for (const table of REQUIRED_TABLES) {
        if (!tableExists(db, table)) errors.push(`Backup package DB missing table ${table}.`);
      }
    } catch (error) {
      errors.push(`Backup package DB is not readable: ${error.message}`);
    } finally {
      if (db) db.close();
    }
  }

  return { ok: errors.length === 0, errors, manifest, manifestPath, dbPath };
}

async function preserveCurrentSpineForRestore({ storageRoot, dbPath, actor, actorId, actorName, reason, timestamp, packagePath, beforeIntegrity }) {
  const snapshotId = makeId("restore_recovery");
  const snapshotPath = path.join(storageRoot, "recovery", snapshotId);
  const tempSnapshotPath = path.join(storageRoot, "temp", snapshotId);
  await fsp.mkdir(snapshotPath, { recursive: true });
  await fsp.mkdir(tempSnapshotPath, { recursive: true });

  try {
    if (fs.existsSync(dbPath)) await writeDatabaseSnapshot(dbPath, path.join(tempSnapshotPath, DATABASE_FILE));
    const managedRoot = path.join(tempSnapshotPath, "managed");
    for (const folder of BACKUP_MANAGED_FOLDERS) {
      const sourceFolder = path.join(storageRoot, folder);
      const targetFolder = path.join(managedRoot, folder);
      if (fs.existsSync(sourceFolder)) await fsp.cp(sourceFolder, targetFolder, { recursive: true, force: true });
    }
    await fsp.cp(tempSnapshotPath, snapshotPath, { recursive: true, force: true });
  } finally {
    await fsp.rm(tempSnapshotPath, { recursive: true, force: true });
  }

  const manifest = {
    app: "Project State",
    packageType: "desktop-restore-recovery-snapshot",
    packageVersion: "0.1",
    snapshotId,
    createdAt: timestamp,
    createdBy: actor,
    actorId,
    actorName,
    reason,
    restoringPackagePath: packagePath,
    sourceIntegrity: beforeIntegrity,
    database: fs.existsSync(path.join(snapshotPath, DATABASE_FILE))
      ? {
        path: DATABASE_FILE,
        bytes: fs.statSync(path.join(snapshotPath, DATABASE_FILE)).size,
        checksum: await checksumFile(path.join(snapshotPath, DATABASE_FILE))
      }
      : null
  };
  await fsp.writeFile(path.join(snapshotPath, "manifest.json"), JSON.stringify(manifest, null, 2), "utf8");

  await preserveRecoveryRecord({
    storageRoot,
    dbPath,
    issue: {
      stage: "desktop-restore-preflight",
      message: "Current desktop spine preserved before restore.",
      managedPath: relativeManagedPath(storageRoot, snapshotPath),
      raw: JSON.stringify(manifest, null, 2)
    }
  });

  return {
    id: snapshotId,
    path: snapshotPath,
    managedPath: relativeManagedPath(storageRoot, snapshotPath)
  };
}

async function replaceLiveSpineFromBackupPackage({ storageRoot, dbPath, packagePath, manifest }) {
  const incomingDbPath = resolvePackagePath(packagePath, manifest.database?.path || DATABASE_FILE);
  const tempRestorePath = path.join(storageRoot, "temp", `restore-${safeStamp()}-${crypto.randomBytes(3).toString("hex")}`);
  await fsp.mkdir(tempRestorePath, { recursive: true });
  try {
    await fsp.copyFile(incomingDbPath, path.join(tempRestorePath, DATABASE_FILE));
    for (const folder of BACKUP_MANAGED_FOLDERS) {
      const sourceFolder = path.join(packagePath, "managed", folder);
      const targetFolder = path.join(tempRestorePath, folder);
      if (fs.existsSync(sourceFolder)) await fsp.cp(sourceFolder, targetFolder, { recursive: true, force: true });
      else await fsp.mkdir(targetFolder, { recursive: true });
    }

    if (fs.existsSync(dbPath)) await fsp.rm(dbPath, { force: true });
    await fsp.copyFile(path.join(tempRestorePath, DATABASE_FILE), dbPath);

    for (const folder of BACKUP_MANAGED_FOLDERS) {
      const liveFolder = path.join(storageRoot, folder);
      if (folder === "recovery") {
        await fsp.mkdir(liveFolder, { recursive: true });
        await fsp.cp(path.join(tempRestorePath, folder), liveFolder, { recursive: true, force: true });
        continue;
      }
      await fsp.rm(liveFolder, { recursive: true, force: true });
      await fsp.cp(path.join(tempRestorePath, folder), liveFolder, { recursive: true, force: true });
    }
  } finally {
    await fsp.rm(tempRestorePath, { recursive: true, force: true });
    await ensureSpine(storageRoot);
  }
}

function resolvePackagePath(packagePath, relativePath) {
  const root = path.resolve(packagePath);
  const target = path.resolve(root, relativePath || "");
  if (target !== root && !target.startsWith(`${root}${path.sep}`)) throw new Error("Package path escaped backup package root.");
  return target;
}

async function writeDatabaseSnapshot(dbPath, targetPath) {
  await fsp.mkdir(path.dirname(targetPath), { recursive: true });
  const db = openDatabase(dbPath);
  try {
    db.exec("PRAGMA wal_checkpoint(FULL)");
    db.exec(`VACUUM INTO ${sqlString(targetPath)}`);
  } finally {
    db.close();
  }
}

function sqlString(value) {
  return `'${String(value).replace(/'/g, "''")}'`;
}

async function listPackageFiles(root) {
  if (!fs.existsSync(root)) return [];
  const entries = await fsp.readdir(root, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const entryPath = path.join(root, entry.name);
    if (entry.isDirectory()) files.push(...await listPackageFiles(entryPath));
    else if (entry.isFile()) files.push(entryPath);
  }
  return files;
}

async function checksumFile(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash("sha256");
    const stream = fs.createReadStream(filePath);
    stream.on("data", (chunk) => hash.update(chunk));
    stream.on("error", reject);
    stream.on("end", () => resolve(hash.digest("hex")));
  });
}

function browserExportRawText(payload = {}) {
  if (typeof payload === "string") return payload;
  if (typeof payload.raw === "string") return payload.raw;
  if (payload.data) return JSON.stringify(payload.data);
  if (payload.browserExport) return JSON.stringify(payload.browserExport);
  return JSON.stringify(payload);
}

function browserExportParsedPayload(payload = {}, raw = "") {
  if (payload && typeof payload === "object" && !payload.raw && !payload.data && !payload.browserExport && (payload.store || Array.isArray(payload.projects))) return payload;
  if (payload.data) return payload.data;
  if (payload.browserExport) return payload.browserExport;
  try {
    return JSON.parse(raw);
  } catch (error) {
    throw new Error(`Browser export is not readable JSON: ${error.message}`);
  }
}

function extractStoreFromBrowserExport(parsed) {
  if (parsed?.app === "Project State" && parsed?.backupType === "full-storage-spine" && parsed.store) return parsed.store;
  if (parsed?.app === "Project State" && parsed?.exportType === "raw-current-store" && parsed.store) return parsed.store;
  if (parsed?.app === "Project State" && parsed.project) throw new Error("Single-project exports cannot be migrated into the desktop spine.");
  if (parsed && Array.isArray(parsed.projects)) return parsed;
  throw new Error("Browser export does not contain a full Project State store.");
}

function describeBrowserExport(parsed) {
  return {
    app: parsed?.app || "",
    backupType: parsed?.backupType || "",
    exportType: parsed?.exportType || "",
    exportedAt: parsed?.exportedAt || "",
    schemaVersion: parsed?.schemaVersion || parsed?.store?.schemaVersion || "",
    storageMode: parsed?.storage?.storageMode || parsed?.storageMode || ""
  };
}

function buildMigrationManifest(store, context = {}) {
  const counts = countStorePartsForBridge(store);
  const snapshot = JSON.stringify(store);
  return {
    spineVersion: "0.2.0-desktop",
    layoutVersion: "desktop-sqlite-managed-files-v1",
    migrationType: "browser-json-to-desktop-spine",
    importedAt: nowIso(),
    importedBy: context.actorId || "",
    importReason: context.reason || "",
    sourceFile: context.sourceFile || "",
    source: context.source || {},
    snapshotBytes: Buffer.byteLength(snapshot, "utf8"),
    counts,
    largeContent: {
      attachments: counts.attachments,
      attachmentDataCharacters: collectAttachments(store).reduce((total, item) => total + String(item.dataUrl || "").length, 0),
      extractTextCharacters: (store.projects || []).reduce((total, project) => total + (project.sources || []).reduce((sourceTotal, source) => sourceTotal + (source.extracts || []).reduce((extractTotal, extract) => extractTotal + String(extract.text || "").length, 0), 0), 0)
    },
    splitTargets: {
      meta: 1,
      projects: counts.projects,
      history: counts.changes,
      sources: counts.sources,
      extracts: counts.extracts,
      attachments: counts.attachments,
      drafts: counts.drafts,
      recovery: 0
    }
  };
}

function countStorePartsForBridge(store = {}) {
  const counts = {
    actors: (store.actors || []).length,
    intakeItems: (store.intakeItems || []).length,
    projects: (store.projects || []).length,
    archivedProjects: 0,
    decisions: 0,
    facts: 0,
    sources: 0,
    extracts: 0,
    drafts: 0,
    relationships: 0,
    openQuestions: 0,
    nextActions: 0,
    changes: 0,
    attachments: 0,
    projectSourceLinks: 0,
    objectSourceLinks: 0
  };

  for (const project of store.projects || []) {
    if (project.archived) counts.archivedProjects += 1;
    counts.decisions += (project.decisions || []).length;
    counts.facts += (project.facts || []).length;
    counts.sources += (project.sources || []).length;
    counts.extracts += (project.sources || []).reduce((total, source) => total + (source.extracts || []).length, 0);
    counts.drafts += (project.draftProjects || []).length;
    counts.relationships += (project.relationships || []).length;
    counts.openQuestions += (project.openQuestions || []).length;
    counts.nextActions += (project.nextActions || []).length;
    counts.changes += (project.changes || []).length;
    counts.attachments += collectProjectAttachments(project).length;
    counts.projectSourceLinks += (project.sourceLinks || []).length;

    for (const list of [project.decisions, project.facts, project.relationships, project.openQuestions, project.nextActions, project.draftProjects, project.changes]) {
      for (const item of list || []) counts.objectSourceLinks += (item.sourceLinks || []).length;
    }
    for (const source of project.sources || []) {
      counts.objectSourceLinks += (source.sourceLinks || []).length;
      for (const extract of source.extracts || []) counts.objectSourceLinks += (extract.sourceLinks || []).length;
    }
  }

  return counts;
}

function validateMigrationStore(store = {}) {
  const errors = [];
  const ids = new Set();
  const projectIds = new Set((store.projects || []).map((project) => project.id).filter(Boolean));
  const actorIds = new Set((store.actors || []).map((actor) => actor.id).filter(Boolean));
  const sourceIds = new Set();
  const extractIds = new Set();
  let sourceLinks = 0;

  if (!store || !Array.isArray(store.projects)) errors.push("Store missing projects array.");
  const addId = (id, label) => {
    if (!id) {
      errors.push(`${label} missing id.`);
      return;
    }
    if (ids.has(id)) errors.push(`Duplicate id: ${label}:${id}`);
    ids.add(id);
  };

  for (const actor of store.actors || []) addId(actor.id, "Actor");
  for (const intake of store.intakeItems || []) addId(intake.id, "Intake item");

  for (const project of store.projects || []) {
    addId(project.id, "Project");
    if (!project.name) errors.push(`Project ${project.id || "(missing id)"} missing name.`);
    if (project.updatedBy && !actorIds.has(project.updatedBy)) errors.push(`Project ${project.id} updatedBy missing actor ${project.updatedBy}.`);
    sourceLinks += (project.sourceLinks || []).length;

    for (const decision of project.decisions || []) validateProjectObject(errors, ids, project, decision, "Decision", "decision");
    for (const fact of project.facts || []) validateProjectObject(errors, ids, project, fact, "Fact", "fact");
    for (const question of project.openQuestions || []) validateProjectObject(errors, ids, project, question, "OpenQuestion", "question");
    for (const action of project.nextActions || []) validateProjectObject(errors, ids, project, action, "NextAction", "action");
    for (const relationship of project.relationships || []) {
      validateProjectObject(errors, ids, project, relationship, "Relationship", "relationship");
      if (relationship.targetProjectId && !projectIds.has(relationship.targetProjectId)) errors.push(`Relationship ${relationship.id} missing target project ${relationship.targetProjectId}.`);
    }

    for (const source of project.sources || []) {
      validateProjectObject(errors, ids, project, source, "Source", "source");
      if (source.id) sourceIds.add(source.id);
      sourceLinks += (source.sourceLinks || []).length;
      for (const extract of source.extracts || []) {
        validateProjectObject(errors, ids, project, extract, "Extract", "extract");
        if (extract.sourceId !== source.id) errors.push(`Extract ${extract.id} sourceId mismatch.`);
        if (extract.id) extractIds.add(extract.id);
        sourceLinks += (extract.sourceLinks || []).length;
      }
    }

    for (const draft of project.draftProjects || []) {
      validateProjectObject(errors, ids, project, draft, "DraftProject", "draft");
      if (draft.sourceId && !sourceIds.has(draft.sourceId)) errors.push(`Draft ${draft.id} missing source ${draft.sourceId}.`);
      if (draft.extractId && !extractIds.has(draft.extractId)) errors.push(`Draft ${draft.id} missing extract ${draft.extractId}.`);
    }

    for (const change of project.changes || []) {
      validateProjectObject(errors, ids, project, change, "Change", "change");
      if (!change.actorId && !change.actorName) errors.push(`Change ${change.id} missing actor.`);
      if (!change.timestamp) errors.push(`Change ${change.id} missing timestamp.`);
      if (!change.reason) errors.push(`Change ${change.id} missing reason.`);
      if (!change.details?.objectType && !change.details?.objectId) errors.push(`Change ${change.id} missing changed object detail.`);
    }

    for (const attachment of collectProjectAttachments(project)) {
      addId(attachment.id, "Attachment");
      if (attachment.projectId !== project.id) errors.push(`Attachment ${attachment.id} projectId mismatch.`);
      if (!attachment.attachedToType || !attachment.attachedToId) errors.push(`Attachment ${attachment.id} missing attachment target.`);
    }
  }

  return { errors, idCount: ids.size, sourceLinks };
}

function validateProjectObject(errors, ids, project, record, label, duplicateLabel) {
  if (!record.id) errors.push(`${label} missing id.`);
  else if (ids.has(record.id)) errors.push(`Duplicate id: ${duplicateLabel}:${record.id}`);
  else ids.add(record.id);
  if (record.projectId && record.projectId !== project.id) errors.push(`${label} ${record.id} projectId mismatch.`);
}

function tableExists(db, table) {
  return Boolean(db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?").get(table));
}

function countRows(db, table) {
  return db.prepare(`SELECT COUNT(*) AS count FROM ${table}`).get().count;
}

function compareManifestCount(report, manifest, key, actual) {
  const expected = manifest?.counts?.[key];
  if (typeof expected === "number" && expected !== actual) {
    report.errors.push(`Manifest count mismatch for ${key}: expected ${expected}, found ${actual}`);
  }
}

function compareManifestLargeCount(report, manifest, key, actual) {
  const expected = manifest?.largeContent?.[key] ?? manifest?.splitTargets?.[key];
  if (typeof expected === "number" && expected !== actual) {
    report.errors.push(`Manifest large-content count mismatch for ${key}: expected ${expected}, found ${actual}`);
  }
}

function verifyManagedTextRows(report, db, storageRoot, options) {
  const { table, idColumn, pathColumn, checksumColumn, bytesColumn, label } = options;
  const rows = db.prepare(`
    SELECT ${idColumn} AS id, ${pathColumn} AS managedPath, ${checksumColumn} AS checksum${bytesColumn ? `, ${bytesColumn} AS expectedBytes` : ""}
    FROM ${table}
    WHERE ${pathColumn} IS NOT NULL AND ${pathColumn} != ''
  `).all();

  for (const row of rows) {
    let filePath = "";
    try {
      filePath = resolveManagedPath(storageRoot, row.managedPath);
    } catch (error) {
      report.errors.push(`${label} ${row.id} has unsafe managed path: ${error.message}`);
      continue;
    }
    if (!fs.existsSync(filePath)) {
      report.errors.push(`${label} ${row.id} is missing managed file: ${row.managedPath}`);
      continue;
    }
    const text = fs.readFileSync(filePath, "utf8");
    if (row.checksum && checksumText(text) !== row.checksum) {
      report.errors.push(`${label} ${row.id} checksum mismatch.`);
    }
    if (bytesColumn && typeof row.expectedBytes === "number" && Buffer.byteLength(text, "utf8") !== row.expectedBytes) {
      report.errors.push(`${label} ${row.id} byte length mismatch.`);
    }
    report.checkedFiles[label] += 1;
  }
}

function verifyManagedBinaryRows(report, db, storageRoot, options) {
  const { table, idColumn, pathColumn, checksumColumn, label } = options;
  const rows = db.prepare(`
    SELECT ${idColumn} AS id, ${pathColumn} AS managedPath, ${checksumColumn} AS checksum
    FROM ${table}
    WHERE ${pathColumn} IS NOT NULL AND ${pathColumn} != ''
  `).all();
  for (const row of rows) {
    let filePath = "";
    try {
      filePath = resolveManagedPath(storageRoot, row.managedPath);
    } catch (error) {
      report.errors.push(`${label} ${row.id} has unsafe managed path: ${error.message}`);
      continue;
    }
    if (!fs.existsSync(filePath)) {
      report.errors.push(`${label} ${row.id} is missing managed file: ${row.managedPath}`);
      continue;
    }
    const checksum = crypto.createHash("sha256").update(fs.readFileSync(filePath)).digest("hex");
    if (row.checksum && checksum !== row.checksum) report.errors.push(`${label} ${row.id} checksum mismatch.`);
    report.checkedFiles[label] = (report.checkedFiles[label] || 0) + 1;
  }
}

async function finalizeIntegrityReport(report, { storageRoot, dbPath, preserveOnFailure }) {
  report.ok = report.errors.length === 0;
  if (!report.ok && preserveOnFailure) {
    await preserveRecoveryRecord({
      storageRoot,
      dbPath,
      issue: {
        stage: "desktop-integrity",
        message: "Desktop spine integrity check failed.",
        raw: JSON.stringify(report, null, 2)
      }
    });
  }
  return report;
}

async function saveMeta({ storageRoot, dbPath, payload }) {
  await ensureSpine(storageRoot);
  const db = openDatabase(dbPath);
  try {
    writeMeta(db, "manifest", payload.manifest || payload);
    return { ok: true };
  } finally {
    db.close();
  }
}

async function preserveLegacyRaw({ storageRoot, dbPath, raw }) {
  await ensureSpine(storageRoot);
  const filePath = path.join(storageRoot, "recovery", `legacy-json-${safeStamp()}.json`);
  await fsp.writeFile(filePath, String(raw || ""), "utf8");
  await preserveRecoveryRecord({
    storageRoot,
    dbPath,
    issue: {
      stage: "legacy-json-backup",
      message: "Legacy JSON preserved during desktop spine migration.",
      managedPath: relativeManagedPath(storageRoot, filePath)
    }
  });
  return { ok: true, path: filePath };
}

async function preserveRecoveryRecord({ storageRoot, dbPath, issue }) {
  await ensureSpine(storageRoot);
  const id = issue.id || makeId("recovery");
  const raw = issue.raw || issue.store || "";
  let managedPath = issue.managedPath || "";
  if (raw) {
    const filePath = path.join(storageRoot, "recovery", `${id}.json`);
    await fsp.writeFile(filePath, typeof raw === "string" ? raw : JSON.stringify(raw, null, 2), "utf8");
    managedPath = relativeManagedPath(storageRoot, filePath);
  }
  const record = {
    id,
    date: issue.date || nowIso(),
    ...issue,
    managedPath
  };
  const db = openDatabase(dbPath);
  try {
    insertJson(db, "recovery_records", {
      id: record.id,
      date: record.date,
      stage: record.stage || "",
      message: record.message || "",
      managed_path: record.managedPath || "",
      record_json: JSON.stringify(record)
    });
  } finally {
    db.close();
  }
  return { ok: true, id, managedPath };
}

async function preserveRecoveryRecordWithOpenDb(db, storageRoot, issue = {}) {
  await ensureSpine(storageRoot);
  const id = issue.id || makeId("recovery");
  const raw = issue.raw || issue.store || "";
  let managedPath = issue.managedPath || "";
  if (raw) {
    const filePath = path.join(storageRoot, "recovery", `${id}.json`);
    await fsp.writeFile(filePath, typeof raw === "string" ? raw : JSON.stringify(raw, null, 2), "utf8");
    managedPath = relativeManagedPath(storageRoot, filePath);
  }
  const record = {
    id,
    date: issue.date || nowIso(),
    ...issue,
    managedPath
  };
  insertJson(db, "recovery_records", {
    id: record.id,
    date: record.date,
    stage: record.stage || "",
    message: record.message || "",
    managed_path: record.managedPath || "",
    record_json: JSON.stringify(record)
  });
  return { ok: true, id, managedPath };
}

async function verifyIntegrity({ storageRoot, dbPath, preserveOnFailure = true } = {}) {
  await ensureSpine(storageRoot);
  const report = {
    ok: true,
    checkedAt: nowIso(),
    storageRoot,
    databaseFile: dbPath,
    counts: {},
    checkedFiles: {
      extracts: 0,
      attachments: 0,
      quarantine: 0,
      discoveryExtractions: 0,
      discoveryChunks: 0,
      manifests: 0
    },
    errors: []
  };

  let db = null;
  try {
    for (const folder of FOLDERS) {
      if (!fs.existsSync(path.join(storageRoot, folder))) report.errors.push(`Missing managed folder: ${folder}`);
    }
    if (!fs.existsSync(dbPath)) {
      report.errors.push("Missing project-state.db.");
      return finalizeIntegrityReport(report, { storageRoot, dbPath, preserveOnFailure });
    }

    db = openDatabase(dbPath);
    for (const table of REQUIRED_TABLES) {
      if (!tableExists(db, table)) report.errors.push(`Missing SQLite table: ${table}`);
    }
    if (report.errors.length) return finalizeIntegrityReport(report, { storageRoot, dbPath, preserveOnFailure });

    report.counts = {
      projects: countRows(db, "projects"),
      changes: countRows(db, "changes"),
      sources: countRows(db, "sources"),
      extracts: countRows(db, "extracts"),
      attachments: countRows(db, "attachments"),
      drafts: countRows(db, "draft_projects"),
      ...discoveryTableCounts(db)
    };

    const manifest = readMeta(db, "manifest") || {};
    compareManifestCount(report, manifest, "projects", report.counts.projects);
    compareManifestCount(report, manifest, "changes", report.counts.changes);
    compareManifestCount(report, manifest, "sources", report.counts.sources);
    compareManifestCount(report, manifest, "extracts", report.counts.extracts);
    compareManifestCount(report, manifest, "drafts", report.counts.drafts);
    compareManifestLargeCount(report, manifest, "attachments", report.counts.attachments);

    verifyManagedTextRows(report, db, storageRoot, {
      table: "extracts",
      idColumn: "id",
      pathColumn: "text_path",
      checksumColumn: "checksum",
      bytesColumn: "text_bytes",
      label: "extracts"
    });
    verifyManagedTextRows(report, db, storageRoot, {
      table: "attachments",
      idColumn: "id",
      pathColumn: "managed_path",
      checksumColumn: "checksum",
      bytesColumn: "",
      label: "attachments"
    });
    verifyManagedBinaryRows(report, db, storageRoot, {
      table: "sources",
      idColumn: "id",
      pathColumn: "managed_path",
      checksumColumn: "checksum",
      label: "sources"
    });
    verifyManagedBinaryRows(report, db, storageRoot, {
      table: "file_versions",
      idColumn: "id",
      pathColumn: "managed_path",
      checksumColumn: "sha256",
      label: "quarantine"
    });
    verifyManagedTextRows(report, db, storageRoot, { table: "discovery_extractions", idColumn: "id", pathColumn: "text_path", checksumColumn: "text_sha256", bytesColumn: "text_bytes", label: "discoveryExtractions" });
    verifyManagedTextRows(report, db, storageRoot, { table: "discovery_chunks", idColumn: "id", pathColumn: "text_path", checksumColumn: "text_sha256", bytesColumn: "text_bytes", label: "discoveryChunks" });

    for (const issue of db.prepare("PRAGMA foreign_key_check").all()) {
      report.errors.push(`SQLite foreign key violation: ${issue.table} row ${issue.rowid}.`);
    }

    const latestManifest = readMeta(db, "latest_manifest_file");
    if (latestManifest?.path) {
      const manifestPath = resolveManagedPath(storageRoot, latestManifest.path);
      if (!fs.existsSync(manifestPath)) report.errors.push(`Latest manifest file is missing: ${latestManifest.path}`);
      else report.checkedFiles.manifests += 1;
    }
  } catch (error) {
    report.errors.push(error.message);
  } finally {
    if (db) db.close();
  }

  return finalizeIntegrityReport(report, { storageRoot, dbPath, preserveOnFailure });
}

async function resetSpine({ storageRoot, dbPath }) {
  await ensureSpine(storageRoot);
  if (fs.existsSync(dbPath)) await fsp.rm(dbPath, { force: true });
  for (const folder of FOLDERS) {
    const target = path.join(storageRoot, folder);
    await fsp.rm(target, { recursive: true, force: true });
  }
  await ensureSpine(storageRoot);
  return { ok: true };
}

function clearWritableTables(db) {
  for (const table of [
    "actors",
    "projects",
    "decisions",
    "facts",
    "open_questions",
    "next_actions",
    "relationships",
    "changes",
    "sources",
    "extracts",
    "extract_chunks",
    "attachments",
    "source_links",
    "intake_batches",
    "intake_items",
    "proposed_projects",
    "proposal_items",
    "draft_projects",
    "approval_records"
  ]) {
    db.prepare(`DELETE FROM ${table}`).run();
  }
}

function writeMeta(db, key, value) {
  db.prepare(`
    INSERT INTO meta (key, value_json, updated_at)
    VALUES (?, ?, ?)
    ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json, updated_at = excluded.updated_at
  `).run(key, JSON.stringify(value || {}), nowIso());
}

function readMeta(db, key) {
  const row = db.prepare("SELECT value_json FROM meta WHERE key = ?").get(key);
  return row?.value_json ? JSON.parse(row.value_json) : null;
}

function insertJson(db, table, row) {
  const keys = Object.keys(row);
  const placeholders = keys.map(() => "?").join(", ");
  db.prepare(`INSERT OR REPLACE INTO ${table} (${keys.join(", ")}) VALUES (${placeholders})`).run(...keys.map((key) => row[key]));
}

function writeActors(db, actors) {
  for (const actor of actors || []) {
    insertJson(db, "actors", {
      id: actor.id,
      name: actor.name || "",
      role: actor.role || "",
      status: actor.status || "",
      record_json: JSON.stringify(actor)
    });
  }
}

function writeIntakeItems(db, items) {
  for (const item of items || []) {
    insertJson(db, "intake_items", {
      id: item.id,
      project_id: item.projectId || "",
      status: item.status || "",
      arm_type: item.armType || "",
      proposed_object_type: item.proposedObjectType || "",
      record_json: JSON.stringify(item)
    });
  }
}

function writeIntakeBatches(db, batches) {
  for (const batch of batches || []) {
    insertJson(db, "intake_batches", {
      id: batch.id,
      status: batch.status || "",
      created_at: batch.createdAt || "",
      record_json: JSON.stringify(batch)
    });
  }
}

function writeProjects(db, projects) {
  for (const project of projects || []) {
    insertJson(db, "projects", {
      id: project.id,
      name: project.name || "",
      archived: project.archived ? 1 : 0,
      updated_at: project.updatedAt || "",
      record_json: JSON.stringify(project)
    });
  }
}

function writeProjectChildren(db, projects) {
  for (const project of projects || []) {
    for (const decision of project.decisions || []) {
      insertJson(db, "decisions", { id: decision.id, project_id: project.id, record_json: JSON.stringify(decision) });
    }
    for (const fact of project.facts || []) {
      insertJson(db, "facts", { id: fact.id, project_id: project.id, record_json: JSON.stringify(fact) });
    }
    for (const question of project.openQuestions || []) {
      insertJson(db, "open_questions", { id: question.id, project_id: project.id, status: question.status || "", record_json: JSON.stringify(question) });
    }
    for (const action of project.nextActions || []) {
      insertJson(db, "next_actions", {
        id: action.id,
        project_id: project.id,
        status: action.status || "",
        due_date: action.dueDate || "",
        completed_at: action.completedAt || "",
        record_json: JSON.stringify(action)
      });
    }
    for (const relationship of project.relationships || []) {
      insertJson(db, "relationships", {
        id: relationship.id,
        project_id: project.id,
        target_project_id: relationship.targetProjectId || "",
        record_json: JSON.stringify(relationship)
      });
    }
  }
}

function writeHistory(db, changes) {
  for (const change of changes || []) {
    insertJson(db, "changes", {
      id: change.id,
      project_id: change.projectId || "",
      actor_id: change.actorId || "",
      timestamp: change.timestamp || "",
      reason: change.reason || "",
      object_type: change.details?.objectType || "",
      object_id: change.details?.objectId || "",
      object_title: change.details?.objectTitle || change.details?.objectText || "",
      record_json: JSON.stringify(change)
    });
  }
}

function writeSources(db, sources) {
  for (const source of sources || []) {
    insertJson(db, "sources", {
      id: source.id,
      project_id: source.projectId || "",
      title: source.title || "",
      source_type: source.sourceType || source.type || "",
      managed_path: source.managedPath || "",
      checksum: source.checksum || "",
      record_json: JSON.stringify(source)
    });
  }
}

async function writeExtracts(db, storageRoot, extracts) {
  for (const extract of extracts || []) {
    const record = { ...extract };
    let textPath = record.textPath || "";
    let checksum = record.checksum || "";
    let bytes = record.textBytes || 0;
    if (record.text) {
      const filePath = path.join(storageRoot, "extracts", record.id, "full-text.txt");
      await fsp.mkdir(path.dirname(filePath), { recursive: true });
      await fsp.writeFile(filePath, record.text, "utf8");
      textPath = relativeManagedPath(storageRoot, filePath);
      checksum = checksumText(record.text);
      bytes = Buffer.byteLength(record.text, "utf8");
      delete record.text;
    }
    record.textPath = textPath;
    record.checksum = checksum;
    record.textBytes = bytes;
    insertJson(db, "extracts", {
      id: record.id,
      project_id: record.projectId || "",
      source_id: record.sourceId || "",
      text_path: textPath,
      checksum,
      text_bytes: bytes,
      record_json: JSON.stringify(record)
    });
  }
}

async function writeAttachments(db, storageRoot, attachments) {
  for (const attachment of attachments || []) {
    const record = { ...attachment };
    let managedPath = record.managedPath || "";
    let checksum = record.checksum || "";
    if (record.dataUrl) {
      const filePath = path.join(storageRoot, "attachments", record.id, "data-url.txt");
      await fsp.mkdir(path.dirname(filePath), { recursive: true });
      await fsp.writeFile(filePath, record.dataUrl, "utf8");
      managedPath = relativeManagedPath(storageRoot, filePath);
      checksum = checksumText(record.dataUrl);
      delete record.dataUrl;
    }
    record.managedPath = managedPath;
    record.checksum = checksum;
    insertJson(db, "attachments", {
      id: record.id,
      project_id: record.projectId || "",
      attached_to_type: record.attachedToType || "",
      attached_to_id: record.attachedToId || "",
      file_name: record.fileName || "",
      managed_path: managedPath,
      checksum,
      record_json: JSON.stringify(record)
    });
  }
}

function writeDrafts(db, drafts) {
  for (const draft of drafts || []) {
    insertJson(db, "draft_projects", {
      id: draft.id,
      project_id: draft.projectId || "",
      source_id: draft.sourceId || "",
      extract_id: draft.extractId || "",
      status: draft.status || "",
      record_json: JSON.stringify(draft)
    });
  }
}

function writeSourceLinks(db, store) {
  for (const project of store.projects || []) {
    collectSourceLinks(project, "Project", project.id, project.sourceLinks, (link) => {
      insertSourceLink(db, project.id, "Project", project.id, link);
    });
    const lists = [
      ["Decision", project.decisions || []],
      ["Fact", project.facts || []],
      ["OpenQuestion", project.openQuestions || []],
      ["NextAction", project.nextActions || []],
      ["Relationship", project.relationships || []],
      ["DraftProject", project.draftProjects || []],
      ["Change", project.changes || []]
    ];
    for (const [objectType, records] of lists) {
      for (const record of records) collectSourceLinks(project, objectType, record.id, record.sourceLinks, (link) => insertSourceLink(db, project.id, objectType, record.id, link));
    }
  }
}

function collectSourceLinks(project, attachedToType, attachedToId, links = [], callback) {
  for (const link of links || []) callback({ ...link, projectId: link.projectId || project.id, attachedToType, attachedToId });
}

function insertSourceLink(db, projectId, attachedToType, attachedToId, link) {
  insertJson(db, "source_links", {
    id: link.id || makeId("source_link"),
    project_id: projectId,
    source_id: link.sourceId || "",
    attached_to_type: attachedToType,
    attached_to_id: attachedToId,
    record_json: JSON.stringify(link)
  });
}

function readSplitRecords(db) {
  return {
    meta: [readMeta(db, "store")].filter(Boolean),
    intakeBatches: readRecordJson(db, "intake_batches"),
    intakeItems: readRecordJson(db, "intake_items"),
    projects: readRecordJson(db, "projects"),
    history: readRecordJson(db, "changes"),
    sources: readRecordJson(db, "sources"),
    extracts: readRecordJson(db, "extracts"),
    attachments: readRecordJson(db, "attachments"),
    drafts: readRecordJson(db, "draft_projects"),
    recovery: readRecordJson(db, "recovery_records")
  };
}

function readRecordJson(db, table) {
  return db.prepare(`SELECT record_json FROM ${table}`).all().map((row) => JSON.parse(row.record_json));
}

async function rebuildStoreFromSplitRecords(storageRoot, split = {}) {
  const meta = (split.meta || [])[0] || {};
  const rebuilt = {
    schemaVersion: meta.schemaVersion || "0.1.0",
    settings: meta.settings || {},
    actors: Array.isArray(meta.actors) ? meta.actors : [],
    intakeBatches: Array.isArray(split.intakeBatches) ? split.intakeBatches : (Array.isArray(meta.intakeBatches) ? meta.intakeBatches : []),
    intakeItems: Array.isArray(split.intakeItems) ? split.intakeItems : (Array.isArray(meta.intakeItems) ? meta.intakeItems : []),
    projects: split.projects || []
  };

  for (const project of rebuilt.projects) {
    project.sources = [];
    project.changes = [];
    project.draftProjects = [];
    project.imageLinks = [];
  }

  const projectById = new Map(rebuilt.projects.map((project) => [project.id, project]));
  for (const source of split.sources || []) {
    const project = projectById.get(source.projectId);
    if (!project) continue;
    source.extracts = [];
    source.imageLinks = [];
    project.sources.push(source);
  }

  const sourceById = new Map();
  for (const project of rebuilt.projects) for (const source of project.sources) sourceById.set(source.id, source);

  for (const extract of split.extracts || []) {
    const source = sourceById.get(extract.sourceId);
    if (!source) continue;
    extract.text = await readManagedText(storageRoot, extract.textPath) || extract.text || "";
    extract.imageLinks = [];
    source.extracts.push(extract);
  }

  for (const change of split.history || []) {
    const project = projectById.get(change.projectId);
    if (!project) continue;
    change.imageLinks = [];
    project.changes.push(change);
  }

  for (const draft of split.drafts || []) {
    const project = projectById.get(draft.projectId);
    if (!project) continue;
    draft.imageLinks = [];
    project.draftProjects.push(draft);
  }

  for (const attachment of split.attachments || []) {
    const project = projectById.get(attachment.projectId);
    if (!project) continue;
    attachment.dataUrl = await readManagedText(storageRoot, attachment.managedPath) || attachment.dataUrl || "";
    const target = findAttachmentTarget(project, attachment.attachedToType, attachment.attachedToId);
    if (!target) continue;
    if (!Array.isArray(target.imageLinks)) target.imageLinks = [];
    target.imageLinks.push(attachment);
  }

  for (const project of rebuilt.projects) {
    delete project.sourceIds;
    delete project.historyIds;
    delete project.draftProjectIds;
    delete project.attachmentIds;
    for (const source of project.sources || []) {
      delete source.extractIds;
      delete source.attachmentIds;
      for (const extract of source.extracts || []) delete extract.attachmentIds;
    }
    for (const draft of project.draftProjects || []) delete draft.attachmentIds;
  }

  return rebuilt;
}

function findAttachmentTarget(project, objectType, objectId) {
  if (objectType === "Project" && project.id === objectId) return project;
  const lists = {
    Decision: project.decisions || [],
    Fact: project.facts || [],
    Relationship: project.relationships || [],
    OpenQuestion: project.openQuestions || [],
    NextAction: project.nextActions || [],
    DraftProject: project.draftProjects || [],
    Change: project.changes || []
  };
  if (lists[objectType]) return lists[objectType].find((item) => item.id === objectId) || null;
  if (objectType === "Source") return (project.sources || []).find((source) => source.id === objectId) || null;
  if (objectType === "Extract") {
    for (const source of project.sources || []) {
      const extract = (source.extracts || []).find((item) => item.id === objectId);
      if (extract) return extract;
    }
  }
  return null;
}

async function readManagedText(storageRoot, managedPath) {
  if (!managedPath) return "";
  const filePath = resolveManagedPath(storageRoot, managedPath);
  if (!fs.existsSync(filePath)) return "";
  return fsp.readFile(filePath, "utf8");
}

async function writeManifestFile(storageRoot, manifest, store) {
  const filePath = path.join(storageRoot, "manifests", `${safeStamp()}-manifest.json`);
  const payload = {
    app: "Project State",
    manifest,
    generatedAt: nowIso(),
    counts: manifest.counts || {},
    checksum: checksumText(JSON.stringify(store))
  };
  await fsp.writeFile(filePath, JSON.stringify(payload, null, 2), "utf8");
  return relativeManagedPath(storageRoot, filePath);
}

function splitStoreRecordsForBridge(store, manifest = {}) {
  return {
    meta: {
      id: "store",
      ...manifest,
      schemaVersion: store.schemaVersion || "0.1.0",
      settings: store.settings || {},
      actors: store.actors || [],
      intakeBatches: store.intakeBatches || [],
      intakeItems: store.intakeItems || []
    },
    projects: (store.projects || []).map((project) => ({
      ...project,
      sourceIds: (project.sources || []).map((source) => source.id),
      historyIds: (project.changes || []).map((change) => change.id),
      draftProjectIds: (project.draftProjects || []).map((draft) => draft.id),
      attachmentIds: (project.imageLinks || []).map((image) => image.id),
      sources: undefined,
      changes: undefined,
      draftProjects: undefined,
      imageLinks: undefined
    })),
    history: (store.projects || []).flatMap((project) => project.changes || []),
    sources: (store.projects || []).flatMap((project) => (project.sources || []).map((source) => ({ ...source, extracts: undefined, imageLinks: undefined }))),
    extracts: (store.projects || []).flatMap((project) => (project.sources || []).flatMap((source) => source.extracts || [])),
    attachments: collectAttachments(store),
    drafts: (store.projects || []).flatMap((project) => project.draftProjects || []),
    recovery: []
  };
}

function collectAttachments(store) {
  const attachments = [];
  for (const project of store.projects || []) attachments.push(...collectProjectAttachments(project));
  return attachments;
}

function collectProjectAttachments(project) {
  const attachments = [];
  const collect = (project, ownerType, ownerId, links = []) => {
    for (const image of links || []) attachments.push({ ...image, projectId: image.projectId || project.id, attachedToType: image.attachedToType || ownerType, attachedToId: image.attachedToId || ownerId });
  };
  collect(project, "Project", project.id, project.imageLinks);
  for (const decision of project.decisions || []) collect(project, "Decision", decision.id, decision.imageLinks);
  for (const fact of project.facts || []) collect(project, "Fact", fact.id, fact.imageLinks);
  for (const relationship of project.relationships || []) collect(project, "Relationship", relationship.id, relationship.imageLinks);
  for (const question of project.openQuestions || []) collect(project, "OpenQuestion", question.id, question.imageLinks);
  for (const action of project.nextActions || []) collect(project, "NextAction", action.id, action.imageLinks);
  for (const change of project.changes || []) collect(project, "Change", change.id, change.imageLinks);
  for (const draft of project.draftProjects || []) collect(project, "DraftProject", draft.id, draft.imageLinks);
  for (const source of project.sources || []) {
    collect(project, "Source", source.id, source.imageLinks);
    for (const extract of source.extracts || []) collect(project, "Extract", extract.id, extract.imageLinks);
  }
  return attachments;
}

function metadata(file) {
  const filePath = pathFromFileLike(file);
  if (filePath && fs.existsSync(filePath)) {
    const stat = fs.statSync(filePath);
    return {
      name: path.basename(filePath),
      type: mimeFromFileName(filePath),
      size: stat.size,
      lastModified: stat.mtime.toISOString()
    };
  }
  if (!file || typeof file.name !== "string" || !file.name) return null;
  return {
    name: file.name,
    type: file.type || "",
    size: file.size || 0,
    lastModified: file.lastModified ? new Date(file.lastModified).toISOString() : ""
  };
}

function localPath(file) {
  return pathFromFileLike(file) || file?.webkitRelativePath || file?.name || "";
}

function verifyLocalFile(reference = {}) {
  const filePath = pathFromFileLike(reference?.path || reference?.localPath || reference);
  const expected = reference?.expected || reference || {};
  const checkedAt = nowIso();

  if (!filePath) {
    return {
      status: "unverifiable",
      exists: false,
      checkedAt,
      reason: "No absolute local path is recorded for this source."
    };
  }

  if (!fs.existsSync(filePath)) {
    return {
      status: "missing",
      exists: false,
      path: filePath,
      checkedAt,
      reason: "The recorded local file path does not exist."
    };
  }

  const stat = fs.statSync(filePath);
  if (!stat.isFile()) {
    return {
      status: "unverifiable",
      exists: true,
      path: filePath,
      checkedAt,
      reason: "The recorded path exists but is not a file."
    };
  }

  const actual = {
    name: path.basename(filePath),
    type: mimeFromFileName(filePath),
    size: stat.size,
    lastModified: stat.mtime.toISOString()
  };
  const expectedSize = Number(expected.size || 0);
  const expectedChecksum = String(expected.sha256 || "").toLowerCase();
  const actualChecksum = expectedChecksum ? crypto.createHash("sha256").update(fs.readFileSync(filePath)).digest("hex") : "";
  const changed = (expectedSize > 0 && expectedSize !== actual.size) || (expectedChecksum && expectedChecksum !== actualChecksum);

  return {
    status: changed ? "changed" : "verified",
    exists: true,
    path: filePath,
    checkedAt,
    actual,
    expected: {
      name: expected.name || "",
      type: expected.type || "",
      size: expectedSize || 0,
      lastModified: expected.lastModified || "",
      sha256: expectedChecksum
    },
    actualChecksum,
    reason: changed ? "The file exists, but it differs from the recorded managed file metadata." : "The file exists and matches recorded managed file metadata."
  };
}

async function readAsText(file) {
  const filePath = pathFromFileLike(file);
  if (filePath) return fsp.readFile(filePath, "utf8");
  if (typeof file?.text === "function") return file.text();
  throw new Error("Desktop bridge could not read text from this file reference.");
}

async function readAsArrayBuffer(file) {
  const filePath = pathFromFileLike(file);
  if (filePath) {
    const buffer = await fsp.readFile(filePath);
    return buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
  }
  if (typeof file?.arrayBuffer === "function") return file.arrayBuffer();
  throw new Error("Desktop bridge could not read bytes from this file reference.");
}

async function readAsDataUrl(file) {
  const filePath = pathFromFileLike(file);
  if (filePath) {
    const buffer = await fsp.readFile(filePath);
    return `data:${mimeFromFileName(filePath)};base64,${buffer.toString("base64")}`;
  }
  const buffer = Buffer.from(await readAsArrayBuffer(file));
  return `data:${file?.type || "application/octet-stream"};base64,${buffer.toString("base64")}`;
}

async function extractText(file) {
  const fileName = pathFromFileLike(file) || file?.name || "";
  const extension = path.extname(fileName).slice(1).toLowerCase();
  if (extension === "txt" || extension === "md") return cleanExtractedText(await readAsText(file));
  const bytes = new Uint8Array(await readAsArrayBuffer(file));
  if (extension === "docx") return extractDocxText(bytes);
  if (extension === "pdf") return extractPdfText(bytes);
  return null;
}

async function saveTextFile({ storageRoot, fileName = "project-state-export.txt", text = "", type = "text/plain" }) {
  await ensureSpine(storageRoot);
  const safeName = safeFileName(fileName);
  const filePath = path.join(storageRoot, "backups", safeName);
  await fsp.writeFile(filePath, String(text || ""), type.includes("json") ? "utf8" : "utf8");
  return { ok: true, path: filePath };
}

function extractDocxText(bytes) {
  const entry = findZipEntry(bytes, "word/document.xml");
  if (!entry) throw new Error("Could not find document text in this DOCX.");
  const xmlBytes = inflateZipEntry(bytes, entry);
  const xml = Buffer.from(xmlBytes).toString("utf8");
  return cleanExtractedText(xmlToText(xml));
}

function findZipEntry(bytes, fileName) {
  for (let i = bytes.length - 22; i >= 0; i -= 1) {
    if (readUint32(bytes, i) !== 0x06054b50) continue;
    const entryCount = readUint16(bytes, i + 10);
    const directoryOffset = readUint32(bytes, i + 16);
    let offset = directoryOffset;
    for (let entryIndex = 0; entryIndex < entryCount; entryIndex += 1) {
      if (readUint32(bytes, offset) !== 0x02014b50) return null;
      const method = readUint16(bytes, offset + 10);
      const compressedSize = readUint32(bytes, offset + 20);
      const fileNameLength = readUint16(bytes, offset + 28);
      const extraLength = readUint16(bytes, offset + 30);
      const commentLength = readUint16(bytes, offset + 32);
      const localHeaderOffset = readUint32(bytes, offset + 42);
      const name = Buffer.from(bytes.slice(offset + 46, offset + 46 + fileNameLength)).toString("utf8");
      if (name === fileName) return { method, compressedSize, localHeaderOffset };
      offset += 46 + fileNameLength + extraLength + commentLength;
    }
  }
  return null;
}

function inflateZipEntry(bytes, entry) {
  const localOffset = entry.localHeaderOffset;
  if (readUint32(bytes, localOffset) !== 0x04034b50) throw new Error("Invalid DOCX file.");
  const nameLength = readUint16(bytes, localOffset + 26);
  const extraLength = readUint16(bytes, localOffset + 28);
  const dataStart = localOffset + 30 + nameLength + extraLength;
  const compressed = bytes.slice(dataStart, dataStart + entry.compressedSize);
  if (entry.method === 0) return compressed;
  if (entry.method !== 8) throw new Error("This DOCX compression method is not supported.");
  return zlib.inflateRawSync(Buffer.from(compressed));
}

function extractPdfText(bytes) {
  const raw = Buffer.from(bytes).toString("latin1");
  const parts = [];
  for (const match of raw.matchAll(/\((?:\\.|[^\\)])*\)\s*Tj/g)) parts.push(decodePdfLiteral(match[0].replace(/\s*Tj$/, "")));
  for (const match of raw.matchAll(/\[(.*?)\]\s*TJ/gs)) {
    for (const literal of match[1].matchAll(/\((?:\\.|[^\\)])*\)/g)) parts.push(decodePdfLiteral(literal[0]));
  }
  return cleanExtractedText(parts.join(" "));
}

function xmlToText(xml = "") {
  return decodeXmlEntities(xml.replace(/<w:tab\/>/g, "\t").replace(/<\/w:p>/g, "\n").replace(/<[^>]+>/g, ""));
}

function decodeXmlEntities(text = "") {
  return text.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&apos;/g, "'");
}

function decodePdfLiteral(value = "") {
  return value
    .replace(/^\(|\)$/g, "")
    .replace(/\\n/g, "\n")
    .replace(/\\r/g, "\r")
    .replace(/\\t/g, "\t")
    .replace(/\\b/g, "\b")
    .replace(/\\f/g, "\f")
    .replace(/\\\(/g, "(")
    .replace(/\\\)/g, ")")
    .replace(/\\\\/g, "\\")
    .replace(/\\([0-7]{1,3})/g, (_, octal) => String.fromCharCode(parseInt(octal, 8)));
}

function readUint16(bytes, offset) {
  return bytes[offset] | (bytes[offset + 1] << 8);
}

function readUint32(bytes, offset) {
  return (bytes[offset] | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24)) >>> 0;
}

function cleanExtractedText(text = "") {
  return String(text).replace(/\r/g, "\n").replace(/\n{3,}/g, "\n\n").replace(/[ \t]{2,}/g, " ").trim();
}

function pathFromFileLike(file) {
  if (typeof file === "string") return path.resolve(file);
  if (file?.path) return path.resolve(file.path);
  if (file?.localPath && path.isAbsolute(file.localPath)) return path.resolve(file.localPath);
  return "";
}

function mimeFromFileName(fileName = "") {
  const extension = path.extname(fileName).slice(1).toLowerCase();
  const types = {
    png: "image/png",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    webp: "image/webp",
    gif: "image/gif",
    pdf: "application/pdf",
    docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    txt: "text/plain",
    md: "text/markdown",
    json: "application/json"
  };
  return types[extension] || "application/octet-stream";
}

function checksumText(text = "") {
  return crypto.createHash("sha256").update(String(text)).digest("hex");
}

function relativeManagedPath(storageRoot, filePath) {
  return path.relative(storageRoot, filePath).replace(/\\/g, "/");
}

function resolveManagedPath(storageRoot, managedPath) {
  const root = path.resolve(storageRoot);
  const filePath = path.resolve(root, managedPath);
  if (filePath !== root && !filePath.startsWith(`${root}${path.sep}`)) throw new Error("Managed path escaped storage root.");
  return filePath;
}

function nowIso() {
  return new Date().toISOString();
}

function safeStamp() {
  return nowIso().replace(/[:.]/g, "-");
}

function safeFileName(value = "") {
  return String(value || "project-state-export.txt").replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").slice(0, 180);
}

function makeId(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${crypto.randomBytes(4).toString("hex")}`;
}

module.exports = {
  createProjectStateDesktopBridge,
  ensureSpine,
  verifyIntegrity,
  FOLDERS,
  BACKUP_MANAGED_FOLDERS,
  REQUIRED_TABLES,
  DATABASE_FILE
};
