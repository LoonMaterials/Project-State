# Project State Universal AI Review Pack

Read the complete package. The provisional concept profile is a synthesized starting hypothesis and raw extraction arrays are supporting signals only. Reviewers may override every profile field. Compare all chunks and collapse duplicates before concept counts. Build concept_clusters first, account for every chunk, and generate final decisions from package-wide concept reconstruction rather than the profile alone. Duplicate repetition must not increase confidence. Use stable IDs and preserve provenance. Treat all results as non-authoritative proposals.
