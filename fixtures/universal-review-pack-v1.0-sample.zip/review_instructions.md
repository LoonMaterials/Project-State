# Project State Universal AI Review Pack

Return JSON that validates against `schema/review_result.schema.json`. Use stable IDs. Treat all results as non-authoritative proposals. One chunk may support multiple decisions and projects.
