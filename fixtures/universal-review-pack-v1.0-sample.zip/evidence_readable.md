# Project State Sample Evidence

## Current Project Registry

- `project_sample_alpha` — **Alpha Project**
- `project_sample_beta` — **Beta Project**

## Chunk `chunk_sample_001`

Alpha Project and Beta Project use the same repeatable validation procedure. A private continuity note is not a commercial default.
